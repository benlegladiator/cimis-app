<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\EnrolementController;
use App\Http\Controllers\CandidatController;
use App\Http\Controllers\CarteController;
use App\Http\Controllers\ImpressionController;
use App\Http\Controllers\VerificationController;
use App\Http\Controllers\CorbeilleController;
use App\Http\Controllers\HistoriqueController;
use App\Http\Controllers\SecuriteController;
use App\Http\Controllers\SignatureController;
use App\Http\Controllers\Api\CarteApiController;

// 1. Authentification & Sas de Sécurité (Public)
Route::match(['get', 'post'], '/', [AuthController::class, 'showGate'])->name('gate');
Route::match(['get', 'post'], '/login', [AuthController::class, 'showLogin'])->name('login');
Route::match(['get', 'post'], '/logout', [AuthController::class, 'logout'])->name('logout');
Route::get('/favicon.ico', function() {
    $path = public_path('favicon.ico');
    if (file_exists($path)) {
        return response()->file($path, ['Content-Type' => 'image/x-icon']);
    }
    return response()->file(public_path('img/cimis.png'), ['Content-Type' => 'image/png']);
});

// Distribution universelle des assets statiques (Photos, Logos, Signatures, CSS, JS)
Route::get('/cimcim/public/{path}', function($path) {
    $file = public_path($path);
    if (is_file($file)) {
        return response()->file($file);
    }
    abort(404);
})->where('path', '.*');

Route::get('/public/{path}', function($path) {
    $file = public_path($path);
    if (is_file($file)) {
        return response()->file($file);
    }
    abort(404);
})->where('path', '.*');

// 2. API REST CIMIS (Cartes, Biométrie et Statistiques pour SIADOC et Partenaires - Sécurisées par Clé d'API)
Route::get('/api/cartes/statistiques', [CarteApiController::class, 'statistiques']);
Route::get('/api/cartes', [CarteApiController::class, 'index']);
Route::get('/api/cartes/{matricule}', [CarteApiController::class, 'show'])->where('matricule', '.*');
Route::get('/api/biometrie/{matricule}', [CarteApiController::class, 'show'])->where('matricule', '.*');

// 3. Routes Protégées de l'Application CIMIS (Requiert Authentification Active)
Route::middleware(['cimis.auth'])->group(function() {
    // 3.1 Tableau de Bord Général
    Route::match(['get', 'post'], '/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // 3.2 Enrôlement Biométrique & Candidats
    Route::match(['get', 'post'], '/enrolement', [EnrolementController::class, 'create'])->name('enrolement.create')->middleware('role:SUPER_ADMIN,ADMIN_ENROLEMENT');
    Route::match(['get', 'post'], '/candidat/edit', [CandidatController::class, 'edit'])->name('candidat.edit')->middleware('role:SUPER_ADMIN,ADMIN_ENROLEMENT');
    Route::match(['get', 'post'], '/candidat/delete', [CandidatController::class, 'delete'])->name('candidat.delete')->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/delete_candidat.php', [CandidatController::class, 'delete'])->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/modifier_candidat.php', [CandidatController::class, 'edit'])->middleware('role:SUPER_ADMIN,ADMIN_ENROLEMENT');
    Route::match(['get', 'post'], '/modifiéer_candidat.php', [CandidatController::class, 'edit'])->middleware('role:SUPER_ADMIN,ADMIN_ENROLEMENT');

    // 3.3 Confection & Visualisation de Carte Militaire PVC
    Route::match(['get', 'post'], '/carte/confection', [CarteController::class, 'confection'])->name('carte.confection');
    Route::match(['get', 'post'], '/carte/visualiser', [CarteController::class, 'visualiser'])->name('carte.visualiser');
    Route::match(['get', 'post'], '/visualiser_carte.php', [CarteController::class, 'visualiser']);
    Route::match(['get', 'post'], '/carte/visualiser_carte.php', [CarteController::class, 'visualiser']);
    Route::match(['get', 'post'], '/carte/3d', [CarteController::class, 'visualiser3D'])->name('carte.3d');
    Route::match(['get', 'post'], '/visualisation_3d.php', [CarteController::class, 'visualiser3D']);
    Route::match(['get', 'post'], '/carte/securite', [CarteController::class, 'securite'])->name('carte.securite');

    // 3.4 Module d'Impression PVC & Reçus A4
    Route::match(['get', 'post'], '/impression', [ImpressionController::class, 'index'])->name('impression.index')->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
    Route::match(['get', 'post'], '/impression/pvc', [ImpressionController::class, 'pvc'])->name('impression.pvc')->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
    Route::match(['get', 'post'], '/impression/recu', [ImpressionController::class, 'recu'])->name('impression.recu')->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
    Route::match(['get', 'post'], '/impression.php', [ImpressionController::class, 'index'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
    Route::match(['get', 'post'], '/impression_pvc.php', [ImpressionController::class, 'pvc'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
    Route::match(['get', 'post'], '/impression_pvc_multiple.php', [ImpressionController::class, 'index'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
    Route::match(['get', 'post'], '/generer_recu.php', [ImpressionController::class, 'recu'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
    Route::match(['get', 'post'], '/backend/generer_recu.php', [ImpressionController::class, 'recu'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');

    // 3.5 Contrôle & Vérification d'Authenticité
    Route::match(['get', 'post'], '/verification', [VerificationController::class, 'index'])->name('verification.index');
    Route::match(['get', 'post'], '/verification.php', [VerificationController::class, 'index']);

    // 3.6 Corbeille
    Route::match(['get', 'post'], '/corbeille', [CorbeilleController::class, 'index'])->name('corbeille.index')->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/corbeille.php', [CorbeilleController::class, 'index'])->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/corbeille_admin.php', [CorbeilleController::class, 'index'])->middleware('role:SUPER_ADMIN');

    // 3.7 Historique & Audit de Sécurité
    Route::match(['get', 'post'], '/historique', [HistoriqueController::class, 'index'])->name('historique.index');
    Route::match(['get', 'post'], '/historique_impressions.php', [HistoriqueController::class, 'index']);
    Route::match(['get', 'post'], '/securite', [SecuriteController::class, 'index'])->name('securite.index')->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/securite.php', [SecuriteController::class, 'index'])->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/securite_admin.php', [SecuriteController::class, 'index'])->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/admin/signatures', [SignatureController::class, 'index'])->name('admin.signatures')->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/securite/signatures', [SignatureController::class, 'index'])->middleware('role:SUPER_ADMIN');

    // 3.8 Passerelle & Console SIADOC
    Route::match(['get', 'post'], '/siadoc', [DashboardController::class, 'siadoc'])->name('siadoc.index')->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/siadoc/', [DashboardController::class, 'siadoc'])->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/siadoc.php', [DashboardController::class, 'siadoc'])->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/api_siadoc.php', [DashboardController::class, 'siadoc'])->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/siadoc_import.php', [DashboardController::class, 'siadoc'])->middleware('role:SUPER_ADMIN');
    Route::match(['get', 'post'], '/backend/siadoc_import.php', [DashboardController::class, 'siadoc'])->middleware('role:SUPER_ADMIN');
});

// 4. Alias /cimcim/* pour compatibilité totale
Route::prefix('cimcim')->group(function() {
    Route::match(['get', 'post'], '/', [AuthController::class, 'showGate']);
    Route::match(['get', 'post'], '/login', [AuthController::class, 'showLogin']);
    Route::match(['get', 'post'], '/logout', [AuthController::class, 'logout']);
    Route::get('/favicon.ico', function() {
        $path = public_path('favicon.ico');
        if (file_exists($path)) {
            return response()->file($path, ['Content-Type' => 'image/x-icon']);
        }
        return response()->file(public_path('img/cimis.png'), ['Content-Type' => 'image/png']);
    });

    // API REST sous préfixe /cimcim
    Route::get('/api/cartes/statistiques', [CarteApiController::class, 'statistiques']);
    Route::get('/api/cartes', [CarteApiController::class, 'index']);
    Route::get('/api/cartes/{matricule}', [CarteApiController::class, 'show'])->where('matricule', '.*');
    Route::get('/api/biometrie/{matricule}', [CarteApiController::class, 'show'])->where('matricule', '.*');

    // Routes internes sous /cimcim protégées par authentification
    Route::middleware(['cimis.auth'])->group(function() {
        Route::match(['get', 'post'], '/dashboard', [DashboardController::class, 'index']);
        Route::match(['get', 'post'], '/enrolement', [EnrolementController::class, 'create'])->middleware('role:SUPER_ADMIN,ADMIN_ENROLEMENT');
        Route::match(['get', 'post'], '/candidat/edit', [CandidatController::class, 'edit'])->middleware('role:SUPER_ADMIN,ADMIN_ENROLEMENT');
        Route::match(['get', 'post'], '/candidat/delete', [CandidatController::class, 'delete'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/delete_candidat.php', [CandidatController::class, 'delete'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/modifier_candidat.php', [CandidatController::class, 'edit'])->middleware('role:SUPER_ADMIN,ADMIN_ENROLEMENT');
        Route::match(['get', 'post'], '/modifiéer_candidat.php', [CandidatController::class, 'edit'])->middleware('role:SUPER_ADMIN,ADMIN_ENROLEMENT');

        Route::match(['get', 'post'], '/carte/confection', [CarteController::class, 'confection']);
        Route::match(['get', 'post'], '/carte/visualiser', [CarteController::class, 'visualiser']);
        Route::match(['get', 'post'], '/carte/3d', [CarteController::class, 'visualiser3D']);
        Route::match(['get', 'post'], '/visualisation_3d.php', [CarteController::class, 'visualiser3D']);
        Route::match(['get', 'post'], '/carte/securite', [CarteController::class, 'securite']);
        Route::match(['get', 'post'], '/visualiser_carte.php', [CarteController::class, 'visualiser']);
        Route::match(['get', 'post'], '/securite_carte.php', [CarteController::class, 'securite']);
        Route::match(['get', 'post'], '/securite_cimis.php', [CarteController::class, 'securite']);

        Route::match(['get', 'post'], '/impression', [ImpressionController::class, 'index'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
        Route::match(['get', 'post'], '/impression/pvc', [ImpressionController::class, 'pvc'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
        Route::match(['get', 'post'], '/impression/recu', [ImpressionController::class, 'recu'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
        Route::match(['get', 'post'], '/impression.php', [ImpressionController::class, 'index'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
        Route::match(['get', 'post'], '/impression_pvc.php', [ImpressionController::class, 'pvc'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
        Route::match(['get', 'post'], '/impression_pvc_multiple.php', [ImpressionController::class, 'index'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
        Route::match(['get', 'post'], '/generer_recu.php', [ImpressionController::class, 'recu'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');
        Route::match(['get', 'post'], '/backend/generer_recu.php', [ImpressionController::class, 'recu'])->middleware('role:SUPER_ADMIN,ADMIN_IMPRESSION');

        Route::match(['get', 'post'], '/verification', [VerificationController::class, 'index']);
        Route::match(['get', 'post'], '/verification.php', [VerificationController::class, 'index']);

        Route::match(['get', 'post'], '/corbeille', [CorbeilleController::class, 'index'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/corbeille.php', [CorbeilleController::class, 'index'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/corbeille_admin.php', [CorbeilleController::class, 'index'])->middleware('role:SUPER_ADMIN');

        Route::match(['get', 'post'], '/historique', [HistoriqueController::class, 'index']);
        Route::match(['get', 'post'], '/historique_impressions.php', [HistoriqueController::class, 'index']);
        Route::match(['get', 'post'], '/securite', [SecuriteController::class, 'index'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/securite.php', [SecuriteController::class, 'index'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/securite_admin.php', [SecuriteController::class, 'index'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/admin/signatures', [SignatureController::class, 'index'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/securite/signatures', [SignatureController::class, 'index'])->middleware('role:SUPER_ADMIN');

        Route::match(['get', 'post'], '/siadoc', [DashboardController::class, 'siadoc'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/siadoc/', [DashboardController::class, 'siadoc'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/siadoc.php', [DashboardController::class, 'siadoc'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/api_siadoc.php', [DashboardController::class, 'siadoc'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/siadoc_import.php', [DashboardController::class, 'siadoc'])->middleware('role:SUPER_ADMIN');
        Route::match(['get', 'post'], '/backend/siadoc_import.php', [DashboardController::class, 'siadoc'])->middleware('role:SUPER_ADMIN');
    });
});

