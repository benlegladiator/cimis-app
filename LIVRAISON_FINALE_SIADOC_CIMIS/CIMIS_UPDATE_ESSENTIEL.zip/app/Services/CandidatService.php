<?php
/**
 * CIMIS - Service MÃ©tier Gestion & Modification Candidat
 * Architecture DÃ©couplÃ©e & SÃ©curisÃ©e
 */

if (!function_exists('getCandidatWithMedical')) {
    /**
     * RÃ©cupÃ¨re un candidat et son dossier mÃ©dical par son ID
     *
     * @param PDO $pdo
     * @param int $id
     * @return array|null Tableau contenant 'candidat' et 'medical', ou null si non trouvÃ©
     */
    function getCandidatWithMedical(PDO $pdo, int $id): ?array {
        $stmt = $pdo->prepare("SELECT * FROM candidat WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $candidat = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$candidat) {
            return null;
        }

        $stmtMed = $pdo->prepare("SELECT * FROM candidat_medical WHERE candidat_id = :id LIMIT 1");
        $stmtMed->execute(['id' => $id]);
        $medical = $stmtMed->fetch(PDO::FETCH_ASSOC) ?: [];

        return [
            'candidat' => $candidat,
            'medical'  => $medical
        ];
    }
}

if (!function_exists('validateCandidatUpdate')) {
    /**
     * Valide les donnÃ©es lors de la modifiÃ©Ã©cation d'un candidat
     *
     * @param PDO $pdo
     * @param int $id ID du candidat actuel
     * @param array $data DonnÃ©es POST
     * @return array DonnÃ©es validÃ©es et normalisÃ©es
     * @throws Exception
     */
    function validateCandidatUpdate(PDO $pdo, int $id, array $data): array {
        $requiredFields = ['nom', 'date_naissance', 'sexe', 'numero_cni'];
        foreach ($requiredFields as $field) {
            if (empty($data[$field])) {
                throw new Exception("Le champ $field est obligatoire.");
            }
        }

        $unite = trim($data['unite'] ?? '');
        $matriculeMilitaire = trim($data['matricule_militaire'] ?? '');

        // Validation matricule militaire pour les corps d'armée
        if (!empty($matriculeMilitaire) && $unite !== 'CIVIL') {
            $formatsAutorises = [
                'ARMÉE DE TERRE'        => '/^([A-Za-z]\d{2,4}|\d{2,4}[A-Za-z])\/\d{3,7}$/',
                'ARMÉE DE L\'AIR'       => '/^([A-Za-z]\d{2,4}|\d{2,4}[A-Za-z])\/\d{3,7}$/',
                'MARINE NATIONALE'      => '/^([A-Za-z]\d{2,4}|\d{2,4}[A-Za-z])\/\d{3,7}$/',
                'GENDARMERIE NATIONALE' => '/^\d{4,7}$/',
                'GENDARMERIE'           => '/^\d{4,7}$/'
            ];

            if (isset($formatsAutorises[$unite]) && !preg_match($formatsAutorises[$unite], $matriculeMilitaire)) {
                throw new Exception("Format du matricule militaire invalide pour l'unitÃ© $unite.");
            }
        }

        // Validation format et unicitÃ© CNI (hors candidat courant)
        $numeroCni = preg_replace('/[^A-Z0-9]/', '', strtoupper(trim($data['numero_cni'])));
        if (strlen($numeroCni) < 9 || strlen($numeroCni) > 20) {
            throw new Exception("Le numÃ©ro CNI doit contenir entre 9 et 20 caractÃ¨res (lettres majuscules et chiffres).");
        }

        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM candidat WHERE numero_cni = :cni AND id != :id");
        $stmt->execute(['cni' => $numeroCni, 'id' => $id]);
        if ((int)$stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0) {
            throw new Exception("Ce numÃ©ro CNI est dÃ©jÃ  utilisÃ© par un autre candidat.");
        }

        // AnnÃ©e dernier galon
        $anneeGalonRaw = $data['annee_dernier_galon'] ?? null;
        $anneeGalonVal = null;
        if (!empty($anneeGalonRaw)) {
            $anneeGalonVal = date('Y', strtotime($anneeGalonRaw));
        }

        return [
            'nom'                 => strtoupper(trim($data['nom'])),
            'prenom'              => strtoupper(trim($data['prenom'] ?? '')),
            'date_naissance'      => $data['date_naissance'],
            'lieu_naissance'      => strtoupper(trim($data['lieu_naissance'] ?? '')),
            'sexe'                => $data['sexe'],
            'numero_cni'          => $numeroCni,
            'taille'              => $data['taille'] ?? '',
            'poids'               => $data['poids'] ?? '',
            'groupe_sanguin'      => $data['groupe_sanguin'] ?? '',
            'matricule_militaire' => $matriculeMilitaire,
            'unite'               => $unite,
            'grade'               => $unite === 'CIVIL' ? 'CIVIL' : ($data['grade'] ?? ''),
            'categorie_civil'     => $unite === 'CIVIL' ? ($data['categorie_civil'] ?? '') : '',
            'annee_dernier_galon' => $anneeGalonVal,
            'suspendus'           => (int)($data['suspendus'] ?? 0),
            'statut_militaire'    => $data['statut_militaire'] ?? 'ACTIF',
            'motif_changement'    => trim($data['motif_changement_statut'] ?? '')
        ];
    }
}

if (!function_exists('processCandidatPhotoUpdate')) {
    /**
     * Traite l'éventuelle nouvelle photo uploadée ou capturée par webcam lors d'une modification
     *
     * @param string $matricule
     * @param string|null $oldPhoto
     * @param array|null $photoFile
     * @param string $rootDir
     * @param string|null $photoDataB64
     * @return string Chemin web vers la photo (ancienne ou nouvelle)
     * @throws Exception
     */
    function processCandidatPhotoUpdate(string $matricule, ?string $oldPhoto, ?array $photoFile, string $rootDir, ?string $photoDataB64 = null): string {
        $storageDir = function_exists('storage_path') ? storage_path('app/public/candidats/') : (rtrim($rootDir, '/\\') . '/storage/app/public/candidats/');
        if (!is_dir($storageDir)) {
            @mkdir($storageDir, 0755, true);
        }
        $cleanMatricule = preg_replace('/[^a-zA-Z0-9_-]/', '_', $matricule);

        // 1. Priorité au flux Base64 issu de la webcam ou du recadrage Cropper
        if (!empty($photoDataB64)) {
            $photoDataB64 = trim($photoDataB64);
            $ext = 'jpg';
            if (preg_match('#^data:image/(\w+);base64,#i', $photoDataB64, $m)) {
                $ext = (strtolower($m[1]) === 'png') ? 'png' : 'jpg';
                $photoDataB64 = substr($photoDataB64, strpos($photoDataB64, ',') + 1);
            }
            $decoded = base64_decode($photoDataB64);
            if ($decoded !== false && strlen($decoded) > 100) {
                $filename = $cleanMatricule . '_' . time() . '.' . $ext;
                $targetPath = $storageDir . $filename;
                file_put_contents($targetPath, $decoded);

                // Nettoyage ancienne photo si distincte
                if (!empty($oldPhoto) && !str_contains($oldPhoto, 'ben.PNG')) {
                    $oldClean = ltrim(str_replace(['../', './'], '', $oldPhoto), '/\\');
                    $oldStoragePath = $storageDir . basename($oldClean);
                    if (file_exists($oldStoragePath) && is_file($oldStoragePath)) {
                        @unlink($oldStoragePath);
                    }
                }

                return 'storage/candidats/' . $filename;
            }
        }

        // 2. Fichier classique uploadé
        if (empty($photoFile) || !isset($photoFile['error']) || $photoFile['error'] !== UPLOAD_ERR_OK) {
            return $oldPhoto ?? '';
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $photoFile['tmp_name']);
        finfo_close($finfo);

        $allowedTypes = ['image/jpeg' => 'jpg', 'image/jpg' => 'jpg', 'image/png' => 'png'];
        if (!isset($allowedTypes[$mimeType])) {
            throw new Exception("Le format de la photo n'est pas valide (JPG ou PNG requis).");
        }

        if ($photoFile['size'] > 2 * 1024 * 1024) {
            throw new Exception("La photo ne doit pas dépasser 2 Mo.");
        }

        $imageInfo = @getimagesize($photoFile['tmp_name']);
        if (!$imageInfo || $imageInfo[0] < 200 || $imageInfo[1] < 200) {
            throw new Exception("La photo doit faire au minimum 200x200 pixels.");
        }

        $extension = $allowedTypes[$mimeType];
        $filename = $cleanMatricule . '_' . time() . '.' . $extension;
        $targetPath = $storageDir . $filename;

        if (!move_uploaded_file($photoFile['tmp_name'], $targetPath)) {
            throw new Exception("Erreur lors de l'enregistrement de la nouvelle photo.");
        }

        if (!empty($oldPhoto) && !str_contains($oldPhoto, 'ben.PNG')) {
            $oldClean = ltrim(str_replace(['../', './'], '', $oldPhoto), '/\\');
            $oldStoragePath = $storageDir . basename($oldClean);
            if (file_exists($oldStoragePath) && is_file($oldStoragePath)) {
                @unlink($oldStoragePath);
            }
        }

        return 'storage/candidats/' . $filename;
    }
}

if (!function_exists('updateCandidatComplete')) {
    /**
     * Met Ã  jour le candidat et son dossier mÃ©dical avec audit et notification SIADOC
     *
     * @param PDO $pdo
     * @param int $id
     * @param array $post
     * @param array $files
     * @param string $rootDir
     * @param string|null $currentUser
     * @param string|null $clientIp
     * @return array
     * @throws Exception
     */
    function updateCandidatComplete(PDO $pdo, int $id, array $post, array $files, string $rootDir, ?string $currentUser = 'ADMIN', ?string $clientIp = '127.0.0.1'): array {
        $candidatData = getCandidatWithMedical($pdo, $id);
        if (!$candidatData) {
            throw new Exception("Candidat introuvable.");
        }
        $candidat = $candidatData['candidat'];

        // 1. Validation des champs
        $validated = validateCandidatUpdate($pdo, $id, $post);

        // 2. Traitement de la photo (Fichier ou Base64 webcam)
        $photoPath = processCandidatPhotoUpdate(
            $candidat['matricule'],
            $candidat['photo'],
            $files['photo'] ?? null,
            $rootDir,
            $post['photo_data'] ?? null
        );

        // 3. Détection des changements de statut / suspension
        $oldSuspendus = (int)($candidat['suspendus'] ?? 0);
        $newSuspendus = $validated['suspendus'];
        $statusChanged = ($oldSuspendus !== $newSuspendus) || ($validated['statut_militaire'] !== ($candidat['statut_militaire'] ?? 'ACTIF'));

        $dateChange = $statusChanged ? date('Y-m-d H:i:s') : ($candidat['date_changement_statut'] ?? date('Y-m-d H:i:s'));
        $autorite   = $statusChanged ? ($currentUser ?: 'ADMIN') : ($candidat['autorite_changement_statut'] ?? ($currentUser ?: 'ADMIN'));
        $motifVal   = !empty($validated['motif_changement']) ? $validated['motif_changement'] : ($newSuspendus == 1 ? 'Suspension administrative de la carte' : 'Changement de statut');

        // 3b. Traitement des empreintes (pouce carte & protocole 4-4-2)
        $empreintePath  = $candidat['empreinte_data'] ?? null;
        $slapGauchePath = $candidat['empreinte_slap_gauche'] ?? null;
        $slapDroitePath = $candidat['empreinte_slap_droite'] ?? null;
        $poucesPath     = $candidat['empreinte_pouces'] ?? null;

        $storageEmpreinteDir = function_exists('storage_path') ? storage_path('app/public/empreintes/') : (rtrim($rootDir, '/\\') . '/storage/app/public/empreintes/');
        if (!is_dir($storageEmpreinteDir)) @mkdir($storageEmpreinteDir, 0755, true);

        $safeMat = preg_replace('/[^a-zA-Z0-9\-_]/', '_', $candidat['matricule'] ?? ('candidat_' . $id));

        // Pouce carte (avec transparence selon l'unité)
        $b64Empreinte = trim($post['empreinte_data_b64'] ?? '');
        if (!empty($b64Empreinte)) {
            if (strpos($b64Empreinte, ',') !== false) {
                $b64Empreinte = substr($b64Empreinte, strpos($b64Empreinte, ',') + 1);
            }
            $imgData = base64_decode($b64Empreinte, true);
            if ($imgData !== false && strlen($imgData) > 50) {
                require_once __DIR__ . '/EnrolementService.php';
                $unitesConfig = file_exists(dirname(__DIR__, 2) . '/config/unites.php') ? (require dirname(__DIR__, 2) . '/config/unites.php') : [];
                $uniteName = trim($validated['unite'] ?? $candidat['unite'] ?? '');
                $corpsClass = $unitesConfig[$uniteName]['class'] ?? 'terre';

                if (function_exists('fingerprintToTransparentPng')) {
                    $transparentData = fingerprintToTransparentPng($imgData, $corpsClass);
                    if ($transparentData && strlen($transparentData) > 2000) {
                        $imgData = $transparentData;
                    }
                }

                $empreinteFilename = 'fp_' . $safeMat . '_carte_' . time() . '.png';
                $empreinteFullPath = $storageEmpreinteDir . $empreinteFilename;
                file_put_contents($empreinteFullPath, $imgData);
                $empreintePath = 'storage/empreintes/' . $empreinteFilename;

                // Mettre également à jour le fichier standard de carte et sa variante transparente
                $standardCartePath = $storageEmpreinteDir . $safeMat . '_carte.png';
                $standardTranspPath = $storageEmpreinteDir . $safeMat . '_carte_transp.png';
                file_put_contents($standardCartePath, $imgData);
                file_put_contents($standardTranspPath, $imgData);
            }
        } else {
            // Si aucune nouvelle empreinte n'a été soumise, vérifier que l'actuelle n'est pas un fichier corrompu (0 pixel / < 2Ko)
            if (!empty($empreintePath)) {
                $currentCheckFile = $storageEmpreinteDir . basename($empreintePath);
                if (file_exists($currentCheckFile) && filesize($currentCheckFile) < 2000) {
                    // Chercher si le fichier standard ou un ancien backup valide existe
                    $altStd = $storageEmpreinteDir . $safeMat . '_carte.png';
                    if (file_exists($altStd) && filesize($altStd) > 2000) {
                        $empreintePath = 'storage/empreintes/' . $safeMat . '_carte.png';
                    }
                }
            }
        }

        // Protocole complet 4-4-2 si soumis
        if (!empty($post['empreinte_slap_gauche_b64'])) {
            $rawG = preg_replace('#^data:image/\w+;base64,#i', '', trim($post['empreinte_slap_gauche_b64']));
            $decG = base64_decode($rawG);
            if ($decG !== false) {
                $fnG = 'fp_' . ($candidat['matricule'] ?? $id) . '_slap_g_' . time() . '.png';
                file_put_contents($storageEmpreinteDir . $fnG, $decG);
                $slapGauchePath = 'storage/empreintes/' . $fnG;
            }
        }

        if (!empty($post['empreinte_slap_droite_b64'])) {
            $rawD = preg_replace('#^data:image/\w+;base64,#i', '', trim($post['empreinte_slap_droite_b64']));
            $decD = base64_decode($rawD);
            if ($decD !== false) {
                $fnD = 'fp_' . ($candidat['matricule'] ?? $id) . '_slap_d_' . time() . '.png';
                file_put_contents($storageEmpreinteDir . $fnD, $decD);
                $slapDroitePath = 'storage/empreintes/' . $fnD;
            }
        }

        if (!empty($post['empreinte_pouces_b64'])) {
            $rawP = preg_replace('#^data:image/\w+;base64,#i', '', trim($post['empreinte_pouces_b64']));
            $decP = base64_decode($rawP);
            if ($decP !== false) {
                $fnP = 'fp_' . ($candidat['matricule'] ?? $id) . '_pouces_' . time() . '.png';
                file_put_contents($storageEmpreinteDir . $fnP, $decP);
                $poucesPath = 'storage/empreintes/' . $fnP;
            }
        }

        $pdo->beginTransaction();
        try {
            // Mise à jour table candidat
            $sql = "UPDATE candidat SET 
                nom = :nom, 
                prenom = :prenom, 
                date_naissance = :date_naissance, 
                lieu_naissance = :lieu_naissance, 
                sexe = :sexe, 
                numero_cni = :numero_cni, 
                taille = :taille, 
                poids = :poids, 
                groupe_sanguin = :groupe_sanguin, 
                matricule_militaire = :matricule_militaire, 
                unite = :unite, 
                grade = :grade, 
                categorie_civil = :categorie_civil, 
                annee_dernier_galon = :annee_dernier_galon, 
                suspendus = :suspendus,
                statut_militaire = :statut_militaire,
                date_changement_statut = :date_changement_statut,
                motif_changement_statut = :motif_changement_statut,
                autorite_changement_statut = :autorite_changement_statut,
                photo = :photo,
                empreinte_data = :empreinte_data,
                empreinte_slap_gauche = :empreinte_slap_gauche,
                empreinte_slap_droite = :empreinte_slap_droite,
                empreinte_pouces = :empreinte_pouces
                WHERE id = :id";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                'nom'                        => $validated['nom'],
                'prenom'                     => $validated['prenom'],
                'date_naissance'             => $validated['date_naissance'],
                'lieu_naissance'             => $validated['lieu_naissance'],
                'sexe'                       => $validated['sexe'],
                'numero_cni'                 => $validated['numero_cni'],
                'taille'                     => $validated['taille'],
                'poids'                      => $validated['poids'],
                'groupe_sanguin'             => $validated['groupe_sanguin'],
                'matricule_militaire'        => $validated['matricule_militaire'],
                'unite'                      => $validated['unite'],
                'grade'                      => $validated['grade'],
                'categorie_civil'            => $validated['categorie_civil'],
                'annee_dernier_galon'        => $validated['annee_dernier_galon'],
                'suspendus'                  => $newSuspendus,
                'statut_militaire'           => $validated['statut_militaire'],
                'date_changement_statut'     => $dateChange,
                'motif_changement_statut'    => $motifVal,
                'autorite_changement_statut' => $autorite,
                'photo'                      => $photoPath,
                'empreinte_data'             => $empreintePath,
                'empreinte_slap_gauche'      => $slapGauchePath,
                'empreinte_slap_droite'      => $slapDroitePath,
                'empreinte_pouces'           => $poucesPath,
                'id'                         => $id
            ]);

            // Journalisation d'audit complète MINDEF (Qui a fait quoi)
            $modifs = [];
            if ($photoPath !== ($candidat['photo'] ?? '')) $modifs[] = "Photo d'identité actualisée";
            if ($empreintePath !== ($candidat['empreinte_data'] ?? '')) $modifs[] = "Empreinte carte actualisée";
            if ($statusChanged) $modifs[] = ($newSuspendus == 1 ? "Carte SUSPENDUE" : "Carte RÉACTIVÉE");
            if ($validated['grade'] !== ($candidat['grade'] ?? '')) $modifs[] = "Grade modifié (" . ($candidat['grade'] ?: 'N/A') . " -> {$validated['grade']})";
            if ($validated['unite'] !== ($candidat['unite'] ?? '')) $modifs[] = "Unité modifiée (" . ($candidat['unite'] ?: 'N/A') . " -> {$validated['unite']})";

            $auditDesc = "Modification fiche militaire " . ($validated['matricule_militaire'] ?: $candidat['matricule']) . " (" . $validated['nom'] . " " . $validated['prenom'] . ")";
            if (!empty($modifs)) {
                $auditDesc .= " : " . implode(', ', $modifs);
            }
            if (function_exists('cimis_audit_log')) {
                cimis_audit_log($pdo, 'CANDIDAT_MODIFICATION', $auditDesc, 'ENROLEMENT', $id, $auditDesc, null, $currentUser, $clientIp);
            }

            // Dossier MÃ©dical SSA (Upsert)
            $hasAllergies = !empty($post['has_allergies']) && $post['has_allergies'] == '1' ? 1 : 0;
            $allergiesDetails = $hasAllergies ? trim($post['allergies_details'] ?? '') : null;

            $hasMaladieChronique = !empty($post['has_maladie_chronique']) && $post['has_maladie_chronique'] == '1' ? 1 : 0;
            $maladieChroniqueDetails = $hasMaladieChronique ? trim($post['maladie_chronique_details'] ?? '') : null;

            $hasMaladieCardiaque = !empty($post['has_maladie_cardiaque']) && $post['has_maladie_cardiaque'] == '1' ? 1 : 0;
            $maladieCardiaqueDetails = $hasMaladieCardiaque ? trim($post['maladie_cardiaque_details'] ?? '') : null;

            $hasMaladieRespiratoire = !empty($post['has_maladie_respiratoire']) && $post['has_maladie_respiratoire'] == '1' ? 1 : 0;
            $maladieRespiratoireDetails = $hasMaladieRespiratoire ? trim($post['maladie_respiratoire_details'] ?? '') : null;

            $hasOperation = !empty($post['has_operation']) && $post['has_operation'] == '1' ? 1 : 0;
            $operationDetails = $hasOperation ? trim($post['operation_details'] ?? '') : null;

            $hasProblemeVue = !empty($post['has_probleme_vue']) && $post['has_probleme_vue'] == '1' ? 1 : 0;
            $problemeVueDetails = $hasProblemeVue ? trim($post['probleme_vue_details'] ?? '') : null;

            $hasProblemeAudition = !empty($post['has_probleme_audition']) && $post['has_probleme_audition'] == '1' ? 1 : 0;
            $problemeAuditionDetails = $hasProblemeAudition ? trim($post['probleme_audition_details'] ?? '') : null;

            $hasHandicap = !empty($post['has_handicap']) && $post['has_handicap'] == '1' ? 1 : 0;
            $handicapDetails = $hasHandicap ? trim($post['handicap_details'] ?? '') : null;

            $hasProblemePsy = !empty($post['has_probleme_psy']) && $post['has_probleme_psy'] == '1' ? 1 : 0;
            $problemePsyDetails = $hasProblemePsy ? trim($post['probleme_psy_details'] ?? '') : null;

            $traitementEnCours = !empty($post['traitement_en_cours']) ? trim($post['traitement_en_cours']) : null;
            $contactUrgenceNom = !empty($post['contact_urgence_nom']) ? trim($post['contact_urgence_nom']) : null;
            $contactUrgenceLien = !empty($post['contact_urgence_lien']) ? trim($post['contact_urgence_lien']) : null;
            $contactUrgenceTelephone = !empty($post['contact_urgence_telephone']) ? trim($post['contact_urgence_telephone']) : null;

            // Dossier Médical SSA (Upsert par vérification explicite)
            $stmtCheck = $pdo->prepare("SELECT id FROM candidat_medical WHERE candidat_id = :cid LIMIT 1");
            $stmtCheck->execute(['cid' => $id]);
            $existingMed = $stmtCheck->fetch(PDO::FETCH_ASSOC);

            if ($existingMed) {
                $sqlMed = "UPDATE candidat_medical SET
                    matricule_militaire = :mat,
                    has_allergies = :ha,
                    allergies_details = :ad,
                    has_maladie_chronique = :hmc,
                    maladie_chronique_details = :mcd,
                    has_maladie_cardiaque = :hcard,
                    maladie_cardiaque_details = :cardd,
                    has_maladie_respiratoire = :hresp,
                    maladie_respiratoire_details = :respd,
                    has_operation = :hop,
                    operation_details = :opd,
                    has_probleme_vue = :hvue,
                    probleme_vue_details = :vued,
                    has_probleme_audition = :haud,
                    probleme_audition_details = :audd,
                    has_handicap = :hhand,
                    handicap_details = :handd,
                    has_probleme_psy = :hpsy,
                    probleme_psy_details = :psyd,
                    traitement_en_cours = :tec,
                    contact_urgence_nom = :cun,
                    contact_urgence_lien = :cul,
                    contact_urgence_telephone = :cut
                    WHERE id = :med_id";
                $medParams = [
                    'med_id' => $existingMed['id'],
                    'mat'   => $validated['matricule_militaire'] ?: ($candidat['matricule'] ?? ''),
                    'ha'    => $hasAllergies,
                    'ad'    => $allergiesDetails,
                    'hmc'   => $hasMaladieChronique,
                    'mcd'   => $maladieChroniqueDetails,
                    'hcard' => $hasMaladieCardiaque,
                    'cardd' => $maladieCardiaqueDetails,
                    'hresp' => $hasMaladieRespiratoire,
                    'respd' => $maladieRespiratoireDetails,
                    'hop'   => $hasOperation,
                    'opd'   => $operationDetails,
                    'hvue'  => $hasProblemeVue,
                    'vued'  => $problemeVueDetails,
                    'haud'  => $hasProblemeAudition,
                    'audd'  => $problemeAuditionDetails,
                    'hhand' => $hasHandicap,
                    'handd' => $handicapDetails,
                    'hpsy'  => $hasProblemePsy,
                    'psyd'  => $problemePsyDetails,
                    'tec'   => $traitementEnCours,
                    'cun'   => $contactUrgenceNom,
                    'cul'   => $contactUrgenceLien,
                    'cut'   => $contactUrgenceTelephone
                ];
                $stmtMed = $pdo->prepare($sqlMed);
                $stmtMed->execute($medParams);
            } else {
                $sqlMed = "INSERT INTO candidat_medical (
                    candidat_id, matricule_militaire,
                    has_allergies, allergies_details,
                    has_maladie_chronique, maladie_chronique_details,
                    has_maladie_cardiaque, maladie_cardiaque_details,
                    has_maladie_respiratoire, maladie_respiratoire_details,
                    has_operation, operation_details,
                    has_probleme_vue, probleme_vue_details,
                    has_probleme_audition, probleme_audition_details,
                    has_handicap, handicap_details,
                    has_probleme_psy, probleme_psy_details,
                    traitement_en_cours, contact_urgence_nom, contact_urgence_lien, contact_urgence_telephone
                ) VALUES (
                    :cid, :mat,
                    :ha, :ad,
                    :hmc, :mcd,
                    :hcard, :cardd,
                    :hresp, :respd,
                    :hop, :opd,
                    :hvue, :vued,
                    :haud, :audd,
                    :hhand, :handd,
                    :hpsy, :psyd,
                    :tec, :cun, :cul, :cut
                )";
                $medParams = [
                    'cid'   => $id,
                    'mat'   => $validated['matricule_militaire'] ?: ($candidat['matricule'] ?? ''),
                    'ha'    => $hasAllergies,
                    'ad'    => $allergiesDetails,
                    'hmc'   => $hasMaladieChronique,
                    'mcd'   => $maladieChroniqueDetails,
                    'hcard' => $hasMaladieCardiaque,
                    'cardd' => $maladieCardiaqueDetails,
                    'hresp' => $hasMaladieRespiratoire,
                    'respd' => $maladieRespiratoireDetails,
                    'hop'   => $hasOperation,
                    'opd'   => $operationDetails,
                    'hvue'  => $hasProblemeVue,
                    'vued'  => $problemeVueDetails,
                    'haud'  => $hasProblemeAudition,
                    'audd'  => $problemeAuditionDetails,
                    'hhand' => $hasHandicap,
                    'handd' => $handicapDetails,
                    'hpsy'  => $hasProblemePsy,
                    'psyd'  => $problemePsyDetails,
                    'tec'   => $traitementEnCours,
                    'cun'   => $contactUrgenceNom,
                    'cul'   => $contactUrgenceLien,
                    'cut'   => $contactUrgenceTelephone
                ];
                $stmtMed = $pdo->prepare($sqlMed);
                $stmtMed->execute($medParams);
            }

            $pdo->commit();

            // Régénération instantanée du QR Code sécurisé avec nouvelles données & SSA
            try {
                require_once __DIR__ . '/QrCodeService.php';
                if (function_exists('generateQRCodeForMatricule')) {
                    $completeData = array_merge($candidat, $validated, $post, ['photo' => $photoPath]);
                    generateQRCodeForMatricule($validated['matricule_militaire'] ?: $candidat['matricule'], $completeData);
                }
            } catch (Exception $eQr) {
                error_log("Avertissement QrCode: " . $eQr->getMessage());
            }

            // Notification automatique vers SIADOC à chaque enregistrement/modification
            try {
                $notifySiadocPath = __DIR__ . '/SiadocApiService.php';
                if (file_exists($notifySiadocPath)) {
                    require_once $notifySiadocPath;
                    $matMilitaire = !empty($validated['matricule_militaire']) ? trim($validated['matricule_militaire']) : trim($candidat['matricule_militaire'] ?: $candidat['matricule']);

                    if (function_exists('callSiadocWebhookEvenement') && !empty($matMilitaire)) {
                        callSiadocWebhookEvenement([
                            'evenement' => 'ENROLEMENT_CONFORME',
                            'matricule' => $matMilitaire,
                            'centre'    => 'Station CIMIS',
                            'operateur' => $currentUser ?: 'OPERATEUR_CIMIS',
                            'source'    => 'CIMIS'
                        ]);
                    }

                    // Statut de suspension si applicable
                    if (function_exists('notifySiadocCardStatus') && ($oldSuspendus !== $newSuspendus || isset($post['force_siadoc_notify']))) {
                        $siadocStatut = ($newSuspendus == 1) ? 'DESACTIVE' : 'ACTIVE';
                        $motifSiadoc  = !empty($validated['motif_changement']) ? $validated['motif_changement'] : ($newSuspendus == 1 ? 'Suspension de la carte' : 'Réactivation de la carte');
                        notifySiadocCardStatus($matMilitaire, $siadocStatut, $motifSiadoc);
                    }
                }
            } catch (Exception $eSiadoc) {
                error_log("Avertissement SIADOC: " . $eSiadoc->getMessage());
            }

            return [
                'success'  => true,
                'message'  => 'Candidat modifié avec succès !',
                'redirect' => '/cimcim/impression'
            ];

        } catch (Exception $ex) {
            $pdo->rollBack();
            throw $ex;
        }
    }
}