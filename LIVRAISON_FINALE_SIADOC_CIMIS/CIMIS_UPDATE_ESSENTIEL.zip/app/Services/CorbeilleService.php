<?php
/**
 * CIMIS - Service Corbeille & Restauration des Données
 * Centralise la récupération des fiches supprimées (supprimer = 1), la restauration vers le registre actif (supprimer = 0),
 * la purge définitive et la synchronisation des statuts SIADOC.
 * Le SUPER_ADMIN a une visibilité globale sur toutes les suppressions effectuées par l'ensemble des utilisateurs.
 */

if (!defined('DB_NAME')) {
    require_once dirname(__DIR__, 2) . '/config/config.php';
}

if (!function_exists('getTrashCandidates')) {
    /**
     * Récupère les cartes supprimées dans la corbeille.
     * Si $isAdmin est vrai, renvoie toutes les suppressions de tous les opérateurs.
     */
    function getTrashCandidates(PDO $pdo, string $operator = '', bool $isAdmin = false): array {
        try {
            if ($isAdmin || empty($operator)) {
                $sql = "
                    SELECT id, matricule, matricule_militaire, nom, prenom, unite, grade, photo, 
                           numero_cni, date_dernier_grade, date_suppression, supprime_par 
                    FROM candidat 
                    WHERE supprimer = 1 
                    ORDER BY date_suppression DESC, id DESC
                ";
                $stmt = $pdo->query($sql);
            } else {
                $sql = "
                    SELECT id, matricule, matricule_militaire, nom, prenom, unite, grade, photo, 
                           numero_cni, date_dernier_grade, date_suppression, supprime_par 
                    FROM candidat 
                    WHERE supprimer = 1 AND (supprime_par = :operator OR supprime_par IS NULL)
                    ORDER BY date_suppression DESC, id DESC
                ";
                $stmt = $pdo->prepare($sql);
                $stmt->execute(['operator' => $operator]);
            }
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException $e) {
            error_log("Erreur getTrashCandidates: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('restoreCandidates')) {
    /**
     * Restaure un lot de cartes depuis la corbeille vers le registre officiel
     */
    function restoreCandidates(PDO $pdo, array $ids, string $operator = '', bool $isAdmin = false): int {
        $cleanIds = array_filter(array_map('intval', $ids));
        if (empty($cleanIds)) {
            return 0;
        }

        $placeholders = str_repeat('?,', count($cleanIds) - 1) . '?';

        // 1. Notifier l'API SIADOC si configurée
        try {
            if (file_exists(__DIR__ . '/SiadocApiService.php')) {
                require_once __DIR__ . '/SiadocApiService.php';
                $stmtMats = $pdo->prepare("SELECT matricule_militaire, matricule FROM candidat WHERE id IN ($placeholders)");
                $stmtMats->execute($cleanIds);
                $cands = $stmtMats->fetchAll(PDO::FETCH_ASSOC);
                foreach ($cands as $c) {
                    $mat = $c['matricule_militaire'] ?: $c['matricule'];
                    if (!empty($mat)) {
                        if (function_exists('notifySiadocCardStatus')) {
                            notifySiadocCardStatus($mat, 'ACTIVE', 'Restauration depuis la corbeille par ' . ($operator ?: 'ADMIN'));
                        } elseif (function_exists('notifierSiadocStatutCarte')) {
                            notifierSiadocStatutCarte($mat, 'ACTIVE', 'Restauration depuis la corbeille par ' . ($operator ?: 'ADMIN'));
                        }
                    }
                }
            }
        } catch (Exception $ex) {
            error_log("Avertissement SIADOC lors de restauration: " . $ex->getMessage());
        }

        // 2. Mettre à jour en base (supprimer = 0)
        try {
            if ($isAdmin || empty($operator)) {
                $sql = "UPDATE candidat SET supprimer = 0, supprime_par = NULL, date_suppression = NULL WHERE id IN ($placeholders)";
                $params = $cleanIds;
            } else {
                $sql = "UPDATE candidat SET supprimer = 0, supprime_par = NULL, date_suppression = NULL WHERE id IN ($placeholders) AND (supprime_par = ? OR supprime_par IS NULL)";
                $params = array_merge($cleanIds, [$operator]);
            }

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $restoredCount = $stmt->rowCount();

            // 3. Logger dans activity_log
            if ($restoredCount > 0) {
                if (file_exists(__DIR__ . '/SecurityService.php')) {
                    require_once __DIR__ . '/SecurityService.php';
                    logSecurityActivity($pdo, null, 'RESTAURATION_CORBEILLE', "$restoredCount carte(s) restaurée(s) par $operator");
                }
            }

            return $restoredCount;
        } catch (PDOException $e) {
            error_log("Erreur restoreCandidates: " . $e->getMessage());
            return 0;
        }
    }
}

if (!function_exists('purgeCandidates')) {
    /**
     * Purge définitivement une sélection de cartes
     */
    function purgeCandidates(PDO $pdo, array $ids, string $operator = '', bool $isAdmin = false): int {
        $cleanIds = array_filter(array_map('intval', $ids));
        if (empty($cleanIds)) {
            return 0;
        }

        $placeholders = str_repeat('?,', count($cleanIds) - 1) . '?';

        try {
            if ($isAdmin || empty($operator)) {
                $sql = "DELETE FROM candidat WHERE id IN ($placeholders) AND supprimer = 1";
                $params = $cleanIds;
            } else {
                $sql = "DELETE FROM candidat WHERE id IN ($placeholders) AND supprimer = 1 AND (supprime_par = ? OR supprime_par IS NULL)";
                $params = array_merge($cleanIds, [$operator]);
            }

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $purgedCount = $stmt->rowCount();

            if ($purgedCount > 0 && file_exists(__DIR__ . '/SecurityService.php')) {
                require_once __DIR__ . '/SecurityService.php';
                logSecurityActivity($pdo, null, 'PURGE_CORBEILLE', "Purge définitive de $purgedCount carte(s) par $operator");
            }

            return $purgedCount;
        } catch (PDOException $e) {
            error_log("Erreur purgeCandidates: " . $e->getMessage());
            return 0;
        }
    }
}

if (!function_exists('emptyTrash')) {
    /**
     * Purge définitivement toutes les cartes placées dans la corbeille
     */
    function emptyTrash(PDO $pdo, string $operator = 'SUPER_ADMIN'): int {
        try {
            $stmt = $pdo->prepare("DELETE FROM candidat WHERE supprimer = 1");
            $stmt->execute();
            $purgedCount = $stmt->rowCount();

            if ($purgedCount > 0) {
                if (file_exists(__DIR__ . '/SecurityService.php')) {
                    require_once __DIR__ . '/SecurityService.php';
                    logSecurityActivity($pdo, null, 'PURGE_CORBEILLE', "Purge définitive totale de $purgedCount carte(s) par $operator");
                }
            }

            return $purgedCount;
        } catch (PDOException $e) {
            error_log("Erreur emptyTrash: " . $e->getMessage());
            return 0;
        }
    }
}

if (!function_exists('getTrashCountValue')) {
    /**
     * Retourne le nombre d'éléments dans la corbeille
     */
    function getTrashCountValue(PDO $pdo, string $operator = '', bool $isAdmin = false): int {
        try {
            if ($isAdmin || empty($operator)) {
                $stmt = $pdo->query("SELECT COUNT(*) FROM candidat WHERE supprimer = 1");
                return (int)($stmt->fetchColumn() ?: 0);
            } else {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM candidat WHERE supprimer = 1 AND (supprime_par = :op OR supprime_par IS NULL)");
                $stmt->execute(['op' => $operator]);
                return (int)($stmt->fetchColumn() ?: 0);
            }
        } catch (PDOException $e) {
            return 0;
        }
    }
}

if (!function_exists('softDeleteCandidates')) {
    /**
     * Déplace un lot de cartes vers la corbeille (supprimer = 1)
     */
    function softDeleteCandidates(PDO $pdo, array $ids, string $operator = 'OPERATEUR'): int {
        $cleanIds = array_filter(array_map('intval', $ids));
        if (empty($cleanIds)) {
            return 0;
        }

        $placeholders = str_repeat('?,', count($cleanIds) - 1) . '?';

        // 1. Notifier l'API SIADOC si configurée
        try {
            if (file_exists(__DIR__ . '/SiadocApiService.php')) {
                require_once __DIR__ . '/SiadocApiService.php';
                $stmtMats = $pdo->prepare("SELECT matricule_militaire, matricule FROM candidat WHERE id IN ($placeholders)");
                $stmtMats->execute($cleanIds);
                $cands = $stmtMats->fetchAll(PDO::FETCH_ASSOC);
                foreach ($cands as $c) {
                    $mat = $c['matricule_militaire'] ?: $c['matricule'];
                    if (!empty($mat) && function_exists('notifySiadocCardStatus')) {
                        notifySiadocCardStatus($mat, 'DESACTIVE', 'Déplacement dans la corbeille par ' . ($operator ?: 'OPERATEUR'));
                    }
                }
            }
        } catch (Exception $ex) {
            error_log("Avertissement SIADOC lors de suppression: " . $ex->getMessage());
        }

        // 2. Mettre à jour en base (supprimer = 1)
        try {
            $sql = "UPDATE candidat SET supprimer = 1, supprime_par = ?, date_suppression = NOW() WHERE id IN ($placeholders)";
            $params = array_merge([$operator], $cleanIds);

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $deletedCount = $stmt->rowCount();

            // 3. Logger dans activity_log
            if ($deletedCount > 0 && file_exists(__DIR__ . '/SecurityService.php')) {
                require_once __DIR__ . '/SecurityService.php';
                logSecurityActivity($pdo, null, 'DEPLACEMENT_CORBEILLE', "$deletedCount carte(s) déplacée(s) dans la corbeille par $operator");
            }

            return $deletedCount;
        } catch (PDOException $e) {
            error_log("Erreur softDeleteCandidates: " . $e->getMessage());
            return 0;
        }
    }
}