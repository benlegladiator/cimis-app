<?php
/**
 * CIMIS - Service Métier Enrôlement & Dossier Médical SSA
 * Architecture Découplée & Sécurisée
 */

require_once __DIR__ . '/QrCodeService.php';

if (!function_exists('generateCIMISMatricule')) {
    /**
     * Génère un matricule système CIMIS standardisé et sécurisé
     * Format normalisé MINDEF : Année (2 chiffres) + CIM + Séquentiel (6 chiffres)
     * Capacité : 1 000 000 de cartes par an (adapté aux effectifs des Forces de Défense ~200 000+)
     * Exemples : 
     *  - 1ère carte en 2026 : 26CIM000001
     *  - 87240ème carte en 2027 : 27CIM087240
     */
    function generateCIMISMatricule(PDO $pdo): string {
        $year = date('y'); // 26 pour 2026, 27 pour 2027
        $prefix = $year . "CIM";
        
        $stmt = $pdo->prepare("SELECT matricule FROM candidat WHERE matricule LIKE :pattern ORDER BY id DESC LIMIT 1");
        $stmt->execute(['pattern' => $prefix . '%']);
        $last = $stmt->fetchColumn();
        
        if ($last && str_starts_with($last, $prefix)) {
            $numPart = substr($last, strlen($prefix));
            $nextNum = (int)$numPart + 1;
        } else {
            // Vérification de sécurité pour éviter toute collision avec d'anciens enregistrements
            $oldPrefix = "CIM-" . date('Y');
            $stmtOld = $pdo->prepare("SELECT matricule FROM candidat WHERE matricule LIKE :pattern ORDER BY id DESC LIMIT 1");
            $stmtOld->execute(['pattern' => $oldPrefix . '%']);
            $lastOld = $stmtOld->fetchColumn();
            if ($lastOld && str_starts_with($lastOld, $oldPrefix)) {
                $nextNum = (int)substr($lastOld, strlen($oldPrefix)) + 1;
            } else {
                $nextNum = 1;
            }
        }
        
        do {
            $candidateMatricule = sprintf("%s%06d", $prefix, $nextNum);
            $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM candidat WHERE matricule = ?");
            $checkStmt->execute([$candidateMatricule]);
            $exists = (int)$checkStmt->fetchColumn() > 0;
            if ($exists) {
                $nextNum++;
            }
        } while ($exists);
        
        return $candidateMatricule;
    }
}

if (!function_exists('validateEnrolementData')) {
    /**
     * Valide et nettoie les données saisies lors de l'enrôlement
     */
    function validateEnrolementData(PDO $pdo, array $data): array {
        // 1. Nom & Prénom
        $nom = strtoupper(trim($data['nom'] ?? ''));
        $prenom = strtoupper(trim($data['prenom'] ?? ''));
        if (empty($nom)) {
            throw new Exception("Le nom de famille est obligatoire.");
        }

        // 2. Date de naissance & Âge (minimum 18 ans)
        if (empty($data['date_naissance'])) {
            throw new Exception("La date de naissance est obligatoire.");
        }
        $date_naissance = new DateTime($data['date_naissance']);
        $aujourd_hui = new DateTime();
        $age = $date_naissance->diff($aujourd_hui)->y;
        if ($age < 18) {
            throw new Exception("Le candidat doit avoir au moins 18 ans. Âge calculé: $age ans");
        }

        // 3. Validation du numéro CNI
        $numero_cni = preg_replace('/[^A-Z0-9]/', '', strtoupper(trim($data['numero_cni'] ?? '')));
        if (empty($numero_cni)) {
            // Auto-génération si manquant
            $numero_cni = 'CNI' . date('Ymd') . rand(1000, 9999);
        }

        // 3.1. Vérification unicité CNI
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM candidat WHERE numero_cni = :numero_cni");
        $stmt->execute(['numero_cni' => $numero_cni]);
        if ((int)$stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0) {
            throw new Exception("Le numéro CNI '$numero_cni' est déjà utilisé par un autre enregistrement.");
        }

        // 4. Matricule militaire
        $matricule_militaire = strtoupper(trim($data['matricule_militaire'] ?? ''));

        // 5. Validation taille et poids
        $taille = (int)($data['taille'] ?? 175);
        $poids = (int)($data['poids'] ?? 70);
        if ($taille <= 0) $taille = 175;
        if ($poids <= 0) $poids = 70;

        // 6. Corps & Grade
        $unite = trim($data['unite'] ?? 'ARMÉE DE TERRE');
        $isCivil = ($unite === 'CIVIL' || $unite === 'PERSONNEL CIVIL' || ($data['type_personnel'] ?? '') === 'CIVIL');

        $date_promotion = $data['annee_dernier_galon'] ?? '';
        $annee_galon = null;
        if (!empty($date_promotion)) {
            $annee_galon = strlen($date_promotion) === 4 ? $date_promotion : date('Y', strtotime($date_promotion));
        } else {
            $annee_galon = date('Y');
        }

        // 7. Validation matricule militaire par corps d'armée
        if (!$isCivil) {
            if (empty($matricule_militaire)) {
                // Auto-génération matricule militaire si non fourni
                $prefixCorps = 'T';
                if (str_contains($unite, 'AIR')) $prefixCorps = 'A';
                elseif (str_contains($unite, 'MARINE')) $prefixCorps = 'M';
                elseif (str_contains($unite, 'GENDARMERIE')) $prefixCorps = 'G';
                $matricule_militaire = $prefixCorps . date('y') . '/' . rand(1000, 9999);
            }
        } else {
            if (empty($matricule_militaire)) {
                $matricule_militaire = 'CIVIL-' . date('Y') . '-' . rand(1000, 9999);
            }
        }

        // Vérification unicité matricule militaire
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM candidat WHERE matricule_militaire = :matricule_militaire");
        $stmt->execute(['matricule_militaire' => $matricule_militaire]);
        if ((int)$stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0) {
            throw new Exception("Le matricule militaire '$matricule_militaire' est déjà attribué.");
        }

        // Grade civil ou militaire
        $grade = trim($data['grade'] ?? '');
        if (empty($grade)) {
            $grade = $isCivil ? 'AGENT' : 'SOLDAT DE 2EME CLASSE';
        }

        return [
            'nom' => $nom,
            'prenom' => $prenom,
            'date_naissance' => $data['date_naissance'],
            'lieu_naissance' => strtoupper(trim($data['lieu_naissance'] ?? 'CAMEROUN')),
            'sexe' => in_array(strtoupper($data['sexe'] ?? ''), ['FEMININ', 'F']) ? 'FEMININ' : 'MASCULIN',
            'numero_cni' => $numero_cni,
            'taille' => $taille,
            'poids' => $poids,
            'groupe_sanguin' => $data['groupe_sanguin'] ?? 'O+',
            'annee_galon' => $annee_galon,
            'unite' => $unite,
            'grade' => $grade,
            'categorie_civil' => $isCivil ? ($data['categorie_civil'] ?? 'Fonctionnaire') : '',
            'matricule_militaire' => $matricule_militaire,
            'type_personnel' => $isCivil ? 'CIVIL' : 'MILITAIRE'
        ];
    }
}

if (!function_exists('processEnrolementPhoto')) {
    /**
     * Traite et sauvegarde la photo d'identité (base64 ou fichier ou image par défaut)
     */
    function processEnrolementPhoto(string $matricule, ?string $photoData, ?array $photoFile, string $rootDir): string {
        $uploadDir = rtrim($rootDir, '/\\') . '/public/img/candidats/';
        $fallbackDir = rtrim($rootDir, '/\\') . '/img/candidats/';
        
        if (!is_dir($uploadDir)) {
            @mkdir($uploadDir, 0755, true);
        }
        if (!is_dir($fallbackDir)) {
            @mkdir($fallbackDir, 0755, true);
        }

        $photoExtension = 'jpg';
        $binaryData = null;

        $allowedMimes = [
            'image/jpeg' => 'jpg',
            'image/pjpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
        ];

        if (!empty($photoData) && str_contains($photoData, 'base64,')) {
            if (preg_match('/^data:image\/(\w+);base64,/', $photoData, $matches)) {
                $mimeExt = strtolower($matches[1]);
                if (in_array($mimeExt, ['jpeg', 'jpg'])) {
                    $photoExtension = 'jpg';
                } elseif ($mimeExt === 'png') {
                    $photoExtension = 'png';
                } elseif ($mimeExt === 'webp') {
                    $photoExtension = 'webp';
                }
                $photoData = preg_replace('/^data:image\/(\w+);base64,/', '', $photoData);
            }
            $decoded = base64_decode($photoData, true);
            if ($decoded !== false && strlen($decoded) > 0) {
                if (function_exists('finfo_open')) {
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $mime = finfo_buffer($finfo, $decoded);
                    finfo_close($finfo);
                    if (isset($allowedMimes[$mime])) {
                        $binaryData = $decoded;
                        $photoExtension = $allowedMimes[$mime];
                    }
                } else {
                    $binaryData = $decoded;
                }
            }
        } elseif (!empty($photoFile) && isset($photoFile['error']) && $photoFile['error'] === UPLOAD_ERR_OK && !empty($photoFile['tmp_name']) && is_uploaded_file($photoFile['tmp_name'])) {
            if (function_exists('finfo_open')) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime = finfo_file($finfo, $photoFile['tmp_name']);
                finfo_close($finfo);
                if (isset($allowedMimes[$mime])) {
                    $photoExtension = $allowedMimes[$mime];
                    $binaryData = file_get_contents($photoFile['tmp_name']);
                }
            } else {
                $clientExt = strtolower(pathinfo($photoFile['name'], PATHINFO_EXTENSION));
                if (in_array($clientExt, ['jpg', 'jpeg', 'png', 'webp'])) {
                    $photoExtension = ($clientExt === 'jpeg') ? 'jpg' : $clientExt;
                    $binaryData = file_get_contents($photoFile['tmp_name']);
                }
            }
        }

        // Si aucune photo fournie ou format invalide, utiliser une image existante par défaut
        if (empty($binaryData)) {
            $defaultCandidates = [
                rtrim($rootDir, '/\\') . '/public/img/candidats/Capture.PNG',
                rtrim($rootDir, '/\\') . '/public/img/candidats/1000775814.jpg',
                rtrim($rootDir, '/\\') . '/public/img/cameroun.png'
            ];
            foreach ($defaultCandidates as $df) {
                if (file_exists($df)) {
                    $binaryData = file_get_contents($df);
                    $photoExtension = pathinfo($df, PATHINFO_EXTENSION) ?: 'png';
                    break;
                }
            }
        }

        // Si toujours vide, créer un bitmap JPEG basique
        if (empty($binaryData)) {
            if (function_exists('imagecreatetruecolor')) {
                $im = imagecreatetruecolor(300, 360);
                $bg = imagecolorallocate($im, 30, 41, 59);
                imagefill($im, 0, 0, $bg);
                ob_start();
                imagejpeg($im, null, 90);
                $binaryData = ob_get_clean();
                imagedestroy($im);
                $photoExtension = 'jpg';
            }
        }

        $safeMatricule = preg_replace('/[^A-Za-z0-9_-]/', '_', $matricule);
        $filename = $safeMatricule . '_' . time() . '.' . $photoExtension;
        
        $storageDir = function_exists('storage_path') ? storage_path('app/public/candidats/') : (rtrim($rootDir, '/\\') . '/storage/app/public/candidats/');
        if (!is_dir($storageDir)) @mkdir($storageDir, 0755, true);

        @file_put_contents($storageDir . $filename, $binaryData);

        return 'storage/candidats/' . $filename;
    }
}

if (!function_exists('fingerprintToTransparentPng')) {
    /**
     * Convertit une image empreinte en PNG RGBA à fond 100% transparent.
     * Les traits sont anti-aliasés et rendus :
     * - BLANCS pour les corps à fond sombre (Terre, Air, Marine)
     * - NOIRS  pour les corps à fond clair  (Gendarmerie, Civil)
     *
     * @param string $rawBinary  Données binaires de l'image brute (PNG, JPG, BMP...)
     * @param string $corpsClass Classe CSS du corps ('terre','air','marine','gendarmerie','civil')
     * @return string|null       Données binaires PNG RGBA ou null si échec
     */
    function fingerprintToTransparentPng(string $rawBinary, string $corpsClass = 'terre'): ?string {
        if (!function_exists('imagecreatefromstring') || empty($rawBinary)) return null;

        // Cache statique en mémoire pour éviter de recalculer la même empreinte plusieurs fois par requête
        static $fpCache = [];
        $hashKey = md5($rawBinary . '_' . $corpsClass);
        if (isset($fpCache[$hashKey])) {
            return $fpCache[$hashKey];
        }

        $src = @imagecreatefromstring($rawBinary);
        if (!$src) return null;

        if (!imageistruecolor($src)) {
            imagepalettetotruecolor($src);
        }

        $w = imagesx($src);
        $h = imagesy($src);

        $out = imagecreatetruecolor($w, $h);
        imagealphablending($out, false);
        imagesavealpha($out, true);
        $transparent = imagecolorallocatealpha($out, 0, 0, 0, 127);
        imagefilledrectangle($out, 0, 0, $w, $h, $transparent);

        // Détection si l'image possède DÉJÀ un fond transparent
        $corners = [
            imagecolorat($src, 0, 0),
            imagecolorat($src, max(0, $w - 1), 0),
            imagecolorat($src, 0, max(0, $h - 1)),
            imagecolorat($src, max(0, $w - 1), max(0, $h - 1))
        ];

        $cornerAlphas = array_map(fn($c) => ($c >> 24) & 0x7F, $corners);
        $avgCornerAlpha = array_sum($cornerAlphas) / 4;
        $hasAlphaBackground = ($avgCornerAlpha >= 64); // Coins majoritairement transparents

        $darkCorps  = ['terre', 'air', 'marine'];
        $whiteRidge = in_array(strtolower($corpsClass), $darkCorps);

        $visiblePixelCount = 0;

        if ($hasAlphaBackground) {
            // Cas 1 : L'image d'entrée possède DÉJÀ un fond transparent
            for ($y = 0; $y < $h; $y++) {
                for ($x = 0; $x < $w; $x++) {
                    $c = imagecolorat($src, $x, $y);
                    $a = ($c >> 24) & 0x7F;
                    if ($a >= 120) {
                        imagesetpixel($out, $x, $y, $transparent);
                    } else {
                        $visiblePixelCount++;
                        $col = $whiteRidge 
                            ? imagecolorallocatealpha($out, 255, 255, 255, $a)
                            : imagecolorallocatealpha($out, 0, 0, 0, $a);
                        imagesetpixel($out, $x, $y, $col);
                    }
                }
            }
        } else {
            // Cas 2 : Image opaque (détection fond blanc vs fond sombre)
            $lumSum = 0;
            foreach ($corners as $c) {
                $r = ($c >> 16) & 0xFF;
                $g = ($c >> 8) & 0xFF;
                $b = $c & 0xFF;
                $lumSum += (int)(0.299 * $r + 0.587 * $g + 0.114 * $b);
            }
            $avgCornerLum = $lumSum / 4;
            $bgIsWhite = ($avgCornerLum >= 128);

            for ($y = 0; $y < $h; $y++) {
                for ($x = 0; $x < $w; $x++) {
                    $c = imagecolorat($src, $x, $y);
                    $r = ($c >> 16) & 0xFF;
                    $g = ($c >> 8) & 0xFF;
                    $b = $c & 0xFF;
                    $lum = (int)(0.299 * $r + 0.587 * $g + 0.114 * $b);

                    if ($bgIsWhite) {
                        if ($lum >= 225) {
                            imagesetpixel($out, $x, $y, $transparent);
                        } else {
                            $visiblePixelCount++;
                            $intensity = (225 - $lum) / 225.0;
                            $intensity = min(1.0, $intensity * 1.5);
                            $alpha = (int)(127 * (1.0 - $intensity));
                            $alpha = max(0, min(127, $alpha));
                            $col = $whiteRidge 
                                ? imagecolorallocatealpha($out, 255, 255, 255, $alpha)
                                : imagecolorallocatealpha($out, 0, 0, 0, $alpha);
                            imagesetpixel($out, $x, $y, $col);
                        }
                    } else {
                        if ($lum <= 35) {
                            imagesetpixel($out, $x, $y, $transparent);
                        } else {
                            $visiblePixelCount++;
                            $intensity = ($lum - 35) / 220.0;
                            $intensity = min(1.0, $intensity * 1.5);
                            $alpha = (int)(127 * (1.0 - $intensity));
                            $alpha = max(0, min(127, $alpha));
                            $col = $whiteRidge 
                                ? imagecolorallocatealpha($out, 255, 255, 255, $alpha)
                                : imagecolorallocatealpha($out, 0, 0, 0, $alpha);
                            imagesetpixel($out, $x, $y, $col);
                        }
                    }
                }
            }
        }

        imagedestroy($src);

        // Garde-fou de sécurité : Si aucun pixel visible n'a été produit, ne pas détruire l'image d'origine
        if ($visiblePixelCount < 10) {
            imagedestroy($out);
            return $fpCache[$hashKey] = $rawBinary;
        }

        ob_start();
        imagepng($out, null, 6);
        $result = ob_get_clean();
        imagedestroy($out);

        $final = $result ?: null;
        return $fpCache[$hashKey] = $final;
    }
}

if (!function_exists('processEnrolementEmpreinte')) {
    /**
     * Traite et sauvegarde l'empreinte biométrique (RealScan ou upload fichier)
     */
    function processEnrolementEmpreinte(string $matricule, ?string $empreinteBase64, ?array $empreinteFile, string $rootDir, string $suffix = 'carte', string $corpsClass = 'terre'): ?string {
        $storageDir = function_exists('storage_path') ? storage_path('app/public/empreintes/') : (rtrim($rootDir, '/\\') . '/storage/app/public/empreintes/');
        if (!is_dir($storageDir)) @mkdir($storageDir, 0755, true);

        $safeMatricule = preg_replace('/[^A-Za-z0-9_-]/', '_', $matricule);

        // 1. Priorité à la capture directe RealScan (Base64 data URL)
        if (!empty($empreinteBase64) && strpos($empreinteBase64, 'base64,') !== false) {
            $parts = explode('base64,', $empreinteBase64, 2);
            $rawBinary = base64_decode($parts[1]);
            if ($rawBinary && strlen($rawBinary) > 100) {
                $filename = $safeMatricule . '_' . $suffix . '.png';
                // Traitement transparence uniquement pour la carte (suffix='carte')
                if ($suffix === 'carte') {
                    $processed = fingerprintToTransparentPng($rawBinary, $corpsClass);
                    $toSave = $processed ?: $rawBinary;
                } else {
                    $toSave = $rawBinary;
                }
                file_put_contents($storageDir . $filename, $toSave);
                return 'storage/empreintes/' . $filename;
            }
        }

        // 2. Fallback via fichier uploadé
        if (empty($empreinteFile) || !isset($empreinteFile['error']) || $empreinteFile['error'] !== UPLOAD_ERR_OK || empty($empreinteFile['tmp_name']) || !is_uploaded_file($empreinteFile['tmp_name'])) {
            return null;
        }

        // Vérification de la taille (max 5 Mo)
        if (!empty($empreinteFile['size']) && $empreinteFile['size'] > 5 * 1024 * 1024) {
            return null;
        }

        $allowedMimes = [
            'image/png'      => 'png',
            'image/jpeg'     => 'jpg',
            'image/pjpeg'    => 'jpg',
            'image/webp'     => 'webp',
            'image/bmp'      => 'bmp',
            'image/x-ms-bmp' => 'bmp'
        ];

        $ext = null;
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $empreinteFile['tmp_name']);
            finfo_close($finfo);
            if (isset($allowedMimes[$mime])) {
                $ext = $allowedMimes[$mime];
            }
        } else {
            $clientExt = strtolower(pathinfo($empreinteFile['name'], PATHINFO_EXTENSION));
            if (in_array($clientExt, ['png', 'jpg', 'jpeg', 'webp', 'bmp'])) {
                $ext = ($clientExt === 'jpeg') ? 'jpg' : $clientExt;
            }
        }

        if (!$ext) return null;

        $rawBinary = file_get_contents($empreinteFile['tmp_name']);
        $filename  = $safeMatricule . '_' . time() . '.png';

        if ($suffix === 'carte' && $rawBinary) {
            $processed = fingerprintToTransparentPng($rawBinary, $corpsClass);
            $toSave = $processed ?: $rawBinary;
        } else {
            $toSave = $rawBinary;
        }

        if (file_put_contents($storageDir . $filename, $toSave)) {
            return 'storage/empreintes/' . $filename;
        }

        return null;
    }
}


if (!function_exists('extractMedicalData')) {
    function extractMedicalData(array $post): array {
        $keys = [
            'allergies',
            'maladie_chronique',
            'maladie_cardiaque',
            'maladie_respiratoire',
            'operation',
            'probleme_vue',
            'probleme_audition',
            'handicap',
            'probleme_psy'
        ];

        $medical = [];
        foreach ($keys as $key) {
            $hasKey = 'has_' . $key;
            $detailsKey = $key . '_details';
            $isYes = !empty($post[$hasKey]) && ((string)$post[$hasKey] === '1' || strtolower((string)$post[$hasKey]) === 'oui') ? 1 : 0;
            $medical[$hasKey] = $isYes;
            $medical[$detailsKey] = $isYes ? trim($post[$detailsKey] ?? '') : null;
        }

        $medical['traitement_en_cours'] = !empty($post['traitement_en_cours']) ? trim($post['traitement_en_cours']) : null;
        $medical['contact_urgence_nom'] = !empty($post['contact_urgence_nom']) ? trim($post['contact_urgence_nom']) : null;
        $medical['contact_urgence_lien'] = !empty($post['contact_urgence_lien']) ? trim($post['contact_urgence_lien']) : null;
        $medical['contact_urgence_telephone'] = !empty($post['contact_urgence_telephone']) ? trim($post['contact_urgence_telephone']) : null;

        return $medical;
    }
}

if (!function_exists('saveEnrolementCandidat')) {
    function saveEnrolementCandidat(PDO $pdo, array $post, array $files, string $rootDir): array {
        // 1. Validation métier
        $validated = validateEnrolementData($pdo, $post);

        // 2. Génération matricule séquentiel CIMIS garanti unique
        $matricule = !empty($post['matricule']) ? trim($post['matricule']) : '';
        if (!empty($matricule)) {
            $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM candidat WHERE matricule = ?");
            $checkStmt->execute([$matricule]);
            if ((int)$checkStmt->fetchColumn() > 0) {
                $matricule = generateCIMISMatricule($pdo);
            }
        } else {
            $matricule = generateCIMISMatricule($pdo);
        }

        // 3. Traitement des fichiers multimédias
        $photoData = $post['photo_data'] ?? null;
        $photoFile = $files['photo'] ?? null;
        $photoPath = processEnrolementPhoto($matricule, $photoData, $photoFile, $rootDir);

        $unitesConfig = file_exists(dirname(__DIR__, 2) . '/config/unites.php') ? (require dirname(__DIR__, 2) . '/config/unites.php') : [];
        $uniteName = trim($validated['unite'] ?? '');
        $corpsClass = $unitesConfig[$uniteName]['class'] ?? 'terre';

        $empreinteData = $post['empreinte_data'] ?? null;
        $empreinteFile = $files['empreinte'] ?? null;
        $empreintePath = processEnrolementEmpreinte($matricule, $empreinteData, $empreinteFile, $rootDir, 'carte', $corpsClass);

        $slapGaucheData = $post['empreinte_slap_gauche'] ?? null;
        $slapGauchePath = processEnrolementEmpreinte($matricule, $slapGaucheData, null, $rootDir, 'slap_gauche');

        $slapDroiteData = $post['empreinte_slap_droite'] ?? null;
        $slapDroitePath = processEnrolementEmpreinte($matricule, $slapDroiteData, null, $rootDir, 'slap_droite');

        $slapPoucesData = $post['empreinte_pouces'] ?? null;
        $slapPoucesPath = processEnrolementEmpreinte($matricule, $slapPoucesData, null, $rootDir, 'pouces');

        // 4. Extraction du volet médical
        $medical = extractMedicalData($post);

        // 5. Génération QR Code
        $codeQr = '';
        if (function_exists('generateQRCodeForMatricule')) {
            try {
                $codeQr = generateQRCodeForMatricule($validated['matricule_militaire'] ?: $matricule, array_merge($validated, $medical, ['photo' => $photoPath]));
            } catch (Exception $e) {
                error_log("Erreur QR Code: " . $e->getMessage());
            }
        }

        // 6. Insertion sécurisée en base via Transaction PDO
        $dateEnrolement = date('Y-m-d H:i:s');
        $dateDernierGrade = !empty($validated['annee_galon']) ? $validated['annee_galon'] . '-01-01' : null;

        $pdo->beginTransaction();
        try {
            $sqlCandidat = "INSERT INTO candidat (
                matricule, matricule_militaire, nom, prenom, date_naissance, lieu_naissance, sexe, numero_cni, 
                taille, poids, groupe_sanguin, annee_dernier_galon, 
                unite, grade, categorie_civil, photo, empreinte_data, empreinte_slap_gauche, empreinte_slap_droite, empreinte_pouces, date_enrolement, date_dernier_grade, code_qr
            ) VALUES (
                :matricule, :matricule_militaire, :nom, :prenom, :date_naissance, :lieu_naissance, :sexe, :numero_cni,
                :taille, :poids, :groupe_sanguin, :annee_dernier_galon,
                :unite, :grade, :categorie_civil, :photo, :empreinte_data, :empreinte_slap_gauche, :empreinte_slap_droite, :empreinte_pouces, :date_enrolement, :date_dernier_grade, :code_qr
            )";

            $stmt = $pdo->prepare($sqlCandidat);
            $stmt->execute([
                'matricule' => $matricule,
                'matricule_militaire' => $validated['matricule_militaire'],
                'nom' => $validated['nom'],
                'prenom' => $validated['prenom'],
                'date_naissance' => $validated['date_naissance'],
                'lieu_naissance' => $validated['lieu_naissance'],
                'sexe' => $validated['sexe'],
                'numero_cni' => $validated['numero_cni'],
                'taille' => $validated['taille'],
                'poids' => $validated['poids'],
                'groupe_sanguin' => $validated['groupe_sanguin'],
                'annee_dernier_galon' => $validated['annee_galon'],
                'unite' => $validated['unite'],
                'grade' => $validated['grade'],
                'categorie_civil' => $validated['categorie_civil'],
                'photo' => $photoPath,
                'empreinte_data' => $empreintePath,
                'empreinte_slap_gauche' => $slapGauchePath,
                'empreinte_slap_droite' => $slapDroitePath,
                'empreinte_pouces' => $slapPoucesPath,
                'date_enrolement' => $dateEnrolement,
                'date_dernier_grade' => $dateDernierGrade,
                'code_qr' => $codeQr
            ]);

            $candidatId = (int)$pdo->lastInsertId();

            // Insertion du dossier médical SSA
            $sqlMedical = "INSERT INTO candidat_medical (
                candidat_id, matricule_militaire,
                has_allergies, allergies_details,
                has_maladie_chronique, maladie_chronique_details,
                has_maladie_cardiaque, maladie_cardiaque_details,
                has_maladie_respiratoire, maladie_respiratoire_details,
                has_operation, operation_details,
                has_probleme_vue, probleme_vue_details,
                has_probleme_audition, probleme_audition_details,
                has_handicap, handicap_details,
                has_probleme_psy, probleme_psy_details,
                traitement_en_cours, contact_urgence_nom, contact_urgence_lien, contact_urgence_telephone
            ) VALUES (
                ?, ?,
                ?, ?,
                ?, ?,
                ?, ?,
                ?, ?,
                ?, ?,
                ?, ?,
                ?, ?,
                ?, ?,
                ?, ?,
                ?, ?, ?, ?
            )";

            $stmtMed = $pdo->prepare($sqlMedical);
            $stmtMed->execute([
                $candidatId,
                $validated['matricule_militaire'] ?: $matricule,
                $medical['has_allergies'], $medical['allergies_details'],
                $medical['has_maladie_chronique'], $medical['maladie_chronique_details'],
                $medical['has_maladie_cardiaque'], $medical['maladie_cardiaque_details'],
                $medical['has_maladie_respiratoire'], $medical['maladie_respiratoire_details'],
                $medical['has_operation'], $medical['operation_details'],
                $medical['has_probleme_vue'], $medical['probleme_vue_details'],
                $medical['has_probleme_audition'], $medical['probleme_audition_details'],
                $medical['has_handicap'], $medical['handicap_details'],
                $medical['has_probleme_psy'], $medical['probleme_psy_details'],
                $medical['traitement_en_cours'],
                $medical['contact_urgence_nom'],
                $medical['contact_urgence_lien'],
                $medical['contact_urgence_telephone']
            ]);

            $pdo->commit();

            // Notification automatique vers SIADOC lors d'un nouvel enrôlement
            try {
                $notifySiadocPath = __DIR__ . '/SiadocApiService.php';
                if (file_exists($notifySiadocPath)) {
                    require_once $notifySiadocPath;
                    $matMilitaire = !empty($validated['matricule_militaire']) ? trim($validated['matricule_militaire']) : '';
                    if (!empty($matMilitaire) && function_exists('notifySiadocEnrolementConforme')) {
                        notifySiadocEnrolementConforme(
                            $matMilitaire,
                            'Station Enrôlement CIMIS',
                            $_SESSION['username'] ?? 'OPERATEUR_CIMIS'
                        );
                    }
                }
            } catch (Exception $eSiadoc) {
                error_log("Avertissement SIADOC Enrolement webhook: " . $eSiadoc->getMessage());
            }

            // Journalisation d'audit MINDEF (Qui a fait quoi)
            if (function_exists('cimis_audit_log')) {
                $matAffiche = $validated['matricule_militaire'] ?: $matricule;
                $desc = "Enrôlement biométrique réussi : $matAffiche ({$validated['nom']} {$validated['prenom']}, {$validated['grade']} - {$validated['unite']})";
                cimis_audit_log($pdo, 'ENROLEMENT_CREATION', $desc, 'ENROLEMENT', $candidatId, $desc);
            }

            $candidatData = [
                'id' => $candidatId,
                'matricule' => $matricule,
                'matricule_militaire' => $validated['matricule_militaire'],
                'nom' => $validated['nom'],
                'prenom' => $validated['prenom'],
                'date_naissance' => $validated['date_naissance'],
                'sexe' => $validated['sexe'],
                'unite' => $validated['unite'],
                'grade' => $validated['grade'],
                'photo' => $photoPath,
                'empreinte_data' => $empreintePath,
                'empreinte_slap_gauche' => $slapGauchePath,
                'empreinte_slap_droite' => $slapDroitePath,
                'empreinte_pouces' => $slapPoucesPath,
                'numero_cni' => $validated['numero_cni'],
                'date_enrolement' => $dateEnrolement,
                'code_qr' => $codeQr
            ];

            return [
                'success' => true,
                'message' => 'Candidat enrôlé avec succès !',
                'matricule' => $matricule,
                'code_qr' => $codeQr,
                'empreinte_data' => $empreintePath,
                'candidat' => $candidatData
            ];
        } catch (Exception $ex) {
            $pdo->rollBack();
            throw $ex;
        }
    }
}