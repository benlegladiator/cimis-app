<?php
/**
 * CIMIS - Service MÃ©tier de VÃ©rification & ContrÃ´le d'AuthenticitÃ© BiomÃ©trique
 * Architecture DÃ©couplÃ©e & SÃ©curisÃ©e
 */

if (!function_exists('extractMatriculeFromQuery')) {
    /**
     * Extrait intelligemment le matricule ou identifiant à partir d'une chaîne brute
     * (URL scannée, payload JSON, nom de fichier image ou saisie manuelle)
     *
     * @param string $query
     * @return array
     */
    function extractSmartQueryDetails(string $query): array {
        $raw = trim($query);
        $result = [
            'matricule'  => '',
            'id'         => null,
            'photo_hint' => '',
            'raw'        => $raw
        ];

        if (empty($raw)) {
            return $result;
        }

        // 1. Détection URL ou chaîne de requête (mat=..., matricule=..., id=...)
        if (strpos($raw, 'http://') === 0 || strpos($raw, 'https://') === 0 || strpos($raw, '?') !== false || strpos($raw, 'mat=') !== false || strpos($raw, 'free.nf') !== false) {
            $queryString = '';
            if (strpos($raw, '?') !== false) {
                $queryString = substr($raw, strpos($raw, '?') + 1);
            } else {
                $queryString = $raw;
            }
            parse_str($queryString, $params);
            if (!empty($params['mat'])) {
                $result['matricule'] = trim($params['mat']);
                return $result;
            }
            if (!empty($params['matricule'])) {
                $result['matricule'] = trim($params['matricule']);
                return $result;
            }
            if (!empty($params['m'])) {
                $result['matricule'] = trim($params['m']);
                return $result;
            }
            if (!empty($params['id']) && is_numeric($params['id'])) {
                $result['id'] = (int)$params['id'];
                return $result;
            }
        }

        // 2. Détection format JSON
        if (str_starts_with($raw, '{') && str_ends_with($raw, '}')) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                if (!empty($decoded['matricule'])) {
                    $result['matricule'] = trim($decoded['matricule']);
                    return $result;
                }
                if (!empty($decoded['id'])) {
                    $result['id'] = (int)$decoded['id'];
                    return $result;
                }
            }
        }

        // 3. Détection de fichiers images (ex: siadoc_T95_05371_1792074697.jpg, 26CIM000119_1791321291.jpg, M18_78456_qr.png)
        if (preg_match('/\.(png|jpe?g|webp|gif|bmp|tiff)$/i', $raw)) {
            $cleanFilename = basename($raw);
            $result['photo_hint'] = '%' . $cleanFilename . '%';
            $nameNoExt = preg_replace('/\.(png|jpe?g|webp|gif|bmp|tiff)$/i', '', $cleanFilename);
            $nameNoExt = preg_replace('/_qr$/i', '', $nameNoExt);

            // Pattern SIADOC : siadoc_T95_05371_1792074697 => T95/05371
            if (preg_match('/siadoc_([A-Za-z0-9]+_[A-Za-z0-9]+)/i', $nameNoExt, $m)) {
                $result['matricule'] = str_replace('_', '/', $m[1]);
                return $result;
            }

            // Pattern CIMIS officiel : 26CIM000119 ou CIM-20260018 ou CIV-2026-125
            if (preg_match('/(26CIM\d{6}|CIM-?\d+|CIV-?\d+)/i', $nameNoExt, $m)) {
                $result['matricule'] = $m[1];
                return $result;
            }

            // Pattern Matricule Militaire officiel : ex T95_05371 ou T24_55981 ou M18_78456
            if (preg_match('/([A-Z]\d{1,2})_(\d{3,6})/i', $nameNoExt, $m)) {
                $result['matricule'] = $m[1] . '/' . $m[2];
                return $result;
            }

            if (preg_match('/^(photo|candidat|cand)_?(\d+)$/i', $nameNoExt, $m)) {
                $result['id'] = (int)$m[2];
                return $result;
            }

            // Ex: M18_78456 ou T12_16991
            if (preg_match('/^[A-Z0-9]+_[A-Z0-9]+$/i', $nameNoExt)) {
                $result['matricule'] = str_replace('_', '/', $nameNoExt);
                return $result;
            }

            $result['matricule'] = $nameNoExt;
            return $result;
        }

        // 4. Chaîne directe (matricule avec ou sans slashes, CNI, etc.)
        $result['matricule'] = $raw;
        return $result;
    }

    /**
     * Rétrocompatibilité : renvoie directement le matricule extrait sous forme de chaîne
     */
    function extractMatriculeFromQuery(string $query): string {
        $details = extractSmartQueryDetails($query);
        return $details['matricule'] ?: ($details['id'] ? (string)$details['id'] : $query);
    }
}

if (!function_exists('resolveCandidatPhotoSrc')) {
    /**
     * Résout le chemin web accessible depuis le navigateur pour l'affichage de la photo du candidat
     *
     * @param string|null $photo
     * @param string $rootDir
     * @param string|null $photoPath
     * @return string URL web accessible (/cimcim/public/img/...)
     */
    function resolveCandidatPhotoSrc(?string $photo, string $rootDir = '', ?string $photoPath = null, ?string $matricule = null, ?string $matMil = null): string {
        $basePrefix = '/cimcim/public/';
        
        $publicDir = realpath(dirname(__DIR__, 2) . '/public');
        if (!$publicDir) {
            $candidateRoot = rtrim($rootDir, '/\\');
            if (basename($candidateRoot) === 'public') {
                $publicDir = $candidateRoot;
            } elseif (is_dir($candidateRoot . '/public')) {
                $publicDir = $candidateRoot . '/public';
            } elseif (is_dir(dirname(__DIR__, 2) . '/public')) {
                $publicDir = dirname(__DIR__, 2) . '/public';
            } else {
                $publicDir = $candidateRoot;
            }
        }
        $publicDir = rtrim(str_replace('\\', '/', (string)$publicDir), '/') . '/';

        $candidatePhotos = array_filter([$photo, $photoPath]);

        foreach ($candidatePhotos as $candidatePhoto) {
            $clean = preg_replace('#^(\.\./|\./|/cimcim/public/|/cimcim/|public/)+#', '', trim($candidatePhoto));
            $clean = ltrim($clean, '/\\');

            if (file_exists($publicDir . $clean) && is_file($publicDir . $clean)) {
                return $basePrefix . $clean;
            }

            $baseName = basename($clean);

            if (file_exists($publicDir . 'storage/candidats/' . $baseName) && is_file($publicDir . 'storage/candidats/' . $baseName)) {
                return $basePrefix . 'storage/candidats/' . $baseName;
            }

            if (file_exists($publicDir . 'img/candidats/' . $baseName) && is_file($publicDir . 'img/candidats/' . $baseName)) {
                return $basePrefix . 'img/candidats/' . $baseName;
            }

            if (file_exists($publicDir . 'img/' . $baseName) && is_file($publicDir . 'img/' . $baseName)) {
                return $basePrefix . 'img/' . $baseName;
            }

            if (file_exists($publicDir . 'uploads/' . $baseName) && is_file($publicDir . 'uploads/' . $baseName)) {
                return $basePrefix . 'uploads/' . $baseName;
            }
        }

        // Recherche dynamique par matricule si le fichier exact en BDD a un horodatage obsolète
        $searchKeys = array_filter([
            $matricule ? preg_replace('/[^A-Za-z0-9_-]/', '', $matricule) : null,
            $matMil ? str_replace(['/', '\\'], '_', $matMil) : null,
            $matMil ? preg_replace('/[^A-Za-z0-9]/', '', $matMil) : null
        ]);

        foreach ($searchKeys as $key) {
            if (empty($key)) continue;
            $patterns = [
                $publicDir . 'storage/candidats/*' . $key . '*.*',
                $publicDir . 'img/candidats/*' . $key . '*.*'
            ];
            foreach ($patterns as $pattern) {
                $matches = glob($pattern);
                if (!empty($matches)) {
                    foreach ($matches as $match) {
                        if (is_file($match) && preg_match('/\.(jpe?g|png|webp)$/i', $match)) {
                            $relPath = str_replace([$publicDir, '\\'], ['', '/'], $match);
                            return $basePrefix . ltrim($relPath, '/');
                        }
                    }
                }
            }
        }

        return $basePrefix . 'img/1KRISS.PNG';
    }
}

if (!function_exists('verifyCandidatByQuery')) {
    /**
     * Recherche et vérifie l'authenticité d'un candidat à partir d'un matricule, URL scannée ou image
     *
     * @param PDO $pdo
     * @param string $query
     * @param string $rootDir
     * @return array
     */
    function verifyCandidatByQuery(PDO $pdo, string $query, string $rootDir): array {
        $smart = function_exists('extractSmartQueryDetails') ? extractSmartQueryDetails($query) : ['matricule' => trim($query), 'id' => null, 'photo_hint' => ''];
        $mat       = trim($smart['matricule'] ?? '');
        $id        = $smart['id'] ?? null;
        $photoHint = $smart['photo_hint'] ?? '';

        if (empty($mat) && empty($id) && empty($photoHint)) {
            return [
                'success'   => true,
                'found'     => false,
                'query'     => '',
                'raw_query' => $query,
                'message'   => 'Veuillez fournir un matricule ou scanner un code QR valide.'
            ];
        }

        $cleanNorm      = $mat;
        $cleanNoSlash   = str_replace(['/', '-'], '_', $cleanNorm);
        $cleanWithSlash = str_replace(['_', '-'], '/', $cleanNorm);
        $cleanDash      = str_replace(['/', '_'], '-', $cleanNorm);
        $cleanNoDash    = str_replace('-', '', $cleanNorm);

        $sql = "
            SELECT c.*, 
                   m.has_allergies, m.allergies_details,
                   m.has_maladie_chronique, m.maladie_chronique_details,
                   m.has_maladie_cardiaque, m.maladie_cardiaque_details,
                   m.has_maladie_respiratoire, m.maladie_respiratoire_details,
                   m.has_operation, m.operation_details,
                   m.has_probleme_vue, m.probleme_vue_details,
                   m.has_probleme_audition, m.probleme_audition_details,
                   m.has_handicap, m.handicap_details,
                   m.has_probleme_psy, m.probleme_psy_details,
                   m.traitement_en_cours, m.contact_urgence_nom, m.contact_urgence_lien, m.contact_urgence_telephone
            FROM candidat c
            LEFT JOIN candidat_medical m ON m.candidat_id = c.id
            WHERE (
                (:has_mat = 1 AND (
                    c.matricule_militaire = :m1 
                    OR c.matricule = :m2 
                    OR c.numero_cni = :m3
                    OR c.matricule_militaire = :m_slash
                    OR REPLACE(c.matricule_militaire, '/', '_') = :m_noslash
                    OR REPLACE(c.matricule_militaire, '/', '-') = :m_dash
                    OR REPLACE(c.matricule, '-', '') = :m_clean
                ))
                OR (:has_id = 1 AND c.id = :cand_id)
                OR (:has_photo = 1 AND (c.photo LIKE :photo_hint1 OR c.photo_path LIKE :photo_hint2))
            ) 
            AND (c.supprimer = 0 OR c.supprimer IS NULL) 
            LIMIT 1
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'has_mat'     => !empty($cleanNorm) ? 1 : 0,
            'm1'          => $cleanNorm,
            'm2'          => $cleanNorm,
            'm3'          => $cleanNorm,
            'm_slash'     => $cleanWithSlash,
            'm_noslash'   => $cleanNoSlash,
            'm_dash'      => $cleanDash,
            'm_clean'     => $cleanNoDash,
            'has_id'      => !empty($id) ? 1 : 0,
            'cand_id'     => $id ?? 0,
            'has_photo'   => !empty($photoHint) ? 1 : 0,
            'photo_hint1' => $photoHint ?: '',
            'photo_hint2' => $photoHint ?: ''
        ]);
        $candidat = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$candidat) {
            $displayId = !empty($cleanNorm) ? $cleanNorm : (!empty($id) ? "#$id" : basename($query));
            return [
                'success'   => true,
                'found'     => false,
                'query'     => $displayId,
                'raw_query' => $query,
                'message'   => 'Aucun personnel correspondant au matricule ou fichier "' . htmlspecialchars($displayId) . '" n\'a été trouvé dans le registre officiel CIMIS.'
            ];
        }

        if (strtoupper(trim($candidat['unite'] ?? '')) === 'GENDARMERIE') {
            $candidat['unite'] = 'GENDARMERIE NATIONALE';
        }

        $photoSrc = resolveCandidatPhotoSrc(
            $candidat['photo'] ?? null, 
            $rootDir, 
            $candidat['photo_path'] ?? null, 
            $candidat['matricule'] ?? null, 
            $candidat['matricule_militaire'] ?? null
        );

        $isSuspended = (!empty($candidat['suspendus']) && $candidat['suspendus'] == 1) ||
            in_array($candidat['statut_militaire'] ?? '', ['SUSPENDU', 'SUSPENDU_ADMINISTRATIVEMENT', 'SUSPENDU_MEDICAL', 'DESERTEUR', 'REVOQUE']);

        return [
            'success'             => true,
            'found'               => true,
            'candidat'            => $candidat,
            'photo_src'           => $photoSrc,
            'is_suspended'        => $isSuspended,
            'status_label'        => $isSuspended ? 'CARTE SUSPENDUE' : 'AUTHENTIQUE & ACTIF',
            'raw_query'           => $query,
            'extracted_matricule' => $candidat['matricule_militaire'] ?? $candidat['matricule'] ?? $cleanNorm
        ];
    }
}

if (!function_exists('generateVerificationPayload')) {
    /**
     * GÃ©nÃ¨re la signature et la charge utile de vÃ©rification pour un candidat
     *
     * @param array $candidat
     * @param string $matriculeSearch
     * @return array
     */
    function generateVerificationPayload(array $candidat, string $matriculeSearch): array {
        $matMil = $candidat['matricule_militaire'] ?? $candidat['matricule'] ?? $matriculeSearch;
        $nom    = $candidat['nom'] ?? 'CANDIDAT';
        $prenom = $candidat['prenom'] ?? '';
        $sexe   = $candidat['sexe'] ?? 'MASCULIN';
        $dob    = $candidat['date_naissance'] ?? '';
        $cni    = $candidat['numero_cni'] ?? '';
        $grade  = $candidat['grade'] ?? 'MILITAIRE';
        $unite  = $candidat['unite'] ?? 'MINDEF';
        $statut = (!empty($candidat['suspendus']) && $candidat['suspendus'] == 1) ? 'SUSPENDU' : 'ACTIF';
        $time   = time();
        $sig    = hash('sha256', $matMil . $nom . 'MINDEF_CIMIS_2026');

        return [
            'matricule'      => $matMil,
            'nom'            => $nom,
            'prenom'         => $prenom,
            'sexe'           => $sexe,
            'date_naissance' => $dob,
            'cni'            => $cni,
            'grade'          => $grade,
            'unite'          => $unite,
            'statut'         => $statut,
            'timestamp'      => $time,
            'signature'      => $sig
        ];
    }
}