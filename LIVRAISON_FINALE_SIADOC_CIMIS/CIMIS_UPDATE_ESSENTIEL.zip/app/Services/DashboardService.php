<?php
/**
 * CIMIS - Service Tableau de Bord & Statistiques (Ã‰tape 6 DÃ©couplage)
 * Centralise les vÃ©rifications de permissions par module, l'Ã©tat de santÃ© systÃ¨me (GD, PDO, etc.)
 * et le calcul des mÃ©triques pour le tableau de bord militaire.
 */

if (!defined('DB_NAME')) {
    require_once dirname(__DIR__, 2) . '/config/config.php';
}

if (!function_exists('getRoleHierarchyLevel')) {
    /**
     * Retourne le niveau hiÃ©rarchique d'un rÃ´le
     */
    function getRoleHierarchyLevel(string $role): int {
        $hierarchy = [
            'SUPER_ADMIN'      => 4,
            'ADMIN_IMPRESSION' => 3,
            'ADMIN_ENROLEMENT' => 2,
            'OFFICIER'         => 1
        ];
        return $hierarchy[strtoupper(trim($role))] ?? 0;
    }
}

if (!function_exists('hasPermission')) {
    /**
     * VÃ©rifie si un rÃ´le utilisateur satisfait au rÃ´le minimum requis
     */
    function hasPermission(string $requiredRole, string $userRole): bool {
        return getRoleHierarchyLevel($userRole) >= getRoleHierarchyLevel($requiredRole);
    }
}

if (!function_exists('getDashboardModulePermissions')) {
    /**
     * Calcule la matrice complète des droits d'accès aux modules pour un rôle donné
     * Règle de gouvernance MINDEF :
     * - ADMIN_ENROLEMENT : Enrôle et visualise, les 2 autres modules du dashboard (Impression & Contrôle) sont grisés
     * - ADMIN_IMPRESSION : Impression et Contrôle actifs, Enrôlement grisé
     * - SUPER_ADMIN      : Accès total
     */
    function getDashboardModulePermissions(string $userRole): array {
        $role = strtoupper(trim($userRole));

        if ($role === 'SUPER_ADMIN') {
            return [
                'enrolement'   => true,
                'impression'   => true,
                'verification' => true,
                'historique'   => true,
                'security'     => true,
                'corbeille'    => true,
                'siadoc'       => true
            ];
        }

        if ($role === 'ADMIN_ENROLEMENT') {
            return [
                'enrolement'   => true,
                'impression'   => false,
                'verification' => false,
                'historique'   => true,
                'security'     => false,
                'corbeille'    => false,
                'siadoc'       => false
            ];
        }

        if ($role === 'ADMIN_IMPRESSION') {
            return [
                'enrolement'   => false,
                'impression'   => true,
                'verification' => true,
                'historique'   => true,
                'security'     => false,
                'corbeille'    => false,
                'siadoc'       => false
            ];
        }

        // OFFICIER et autres profils
        return [
            'enrolement'   => false,
            'impression'   => false,
            'verification' => true,
            'historique'   => false,
            'security'     => false,
            'corbeille'    => false,
            'siadoc'       => false
        ];
    }
}

if (!function_exists('getSystemHealthStatus')) {
    /**
     * VÃ©rifie l'Ã©tat de santÃ© des composants critiques du systÃ¨me
     */
    function getSystemHealthStatus(PDO $pdo, string $rootDir): array {
        $status = [
            'gd_loaded'          => extension_loaded('gd'),
            'openssl_loaded'     => extension_loaded('openssl'),
            'pdo_connected'      => false,
            'uploads_writable'   => is_writable($rootDir . '/backend/uploads') || is_writable($rootDir . '/uploads'),
            'logs_writable'      => is_writable($rootDir . '/logs'),
            'warnings'           => []
        ];

        try {
            $pdo->query("SELECT 1");
            $status['pdo_connected'] = true;
        } catch (Exception $e) {
            $status['pdo_connected'] = false;
            $status['warnings'][] = "Erreur de connexion Ã  la base de donnÃ©es : " . $e->getMessage();
        }

        if (!$status['gd_loaded']) {
            $status['warnings'][] = "L'extension PHP GD n'est pas activÃ©e. La gÃ©nÃ©ration de codes QR et le traitement d'images sont limitÃ©s.";
        }

        return $status;
    }
}

if (!function_exists('getDashboardStats')) {
    /**
     * RÃ©cupÃ¨re les statistiques globales d'enrÃ´lement et d'impression
     */
    function getDashboardStats(PDO $pdo): array {
        $stats = [
            'total_candidats'   => 0,
            'total_suspendus'   => 0,
            'total_corbeille'   => 0,
            'unites'            => [],
            'statuts'           => [],
            'medical_alerts'    => 0,
            'total_utilisateurs'=> 0
        ];

        try {
            // Total candidats actifs
            $stmt = $pdo->query("SELECT COUNT(*) AS total FROM candidat WHERE (supprimer = 0 OR supprimer IS NULL)");
            $stats['total_candidats'] = (int)($stmt->fetchColumn() ?: 0);

            // Total candidats suspendus
            $stmt = $pdo->query("SELECT COUNT(*) AS total FROM candidat WHERE suspendus = 1 AND (supprimer = 0 OR supprimer IS NULL)");
            $stats['total_suspendus'] = (int)($stmt->fetchColumn() ?: 0);

            // Total corbeille
            $stmt = $pdo->query("SELECT COUNT(*) AS total FROM candidat WHERE supprimer = 1");
            $stats['total_corbeille'] = (int)($stmt->fetchColumn() ?: 0);

            // RÃ©partition par unitÃ© / corps
            $stmt = $pdo->query("
                SELECT COALESCE(unite, 'NON_DEFINI') AS unite, COUNT(*) AS count 
                FROM candidat 
                WHERE (supprimer = 0 OR supprimer IS NULL) 
                GROUP BY unite
            ");
            $stats['unites'] = $stmt->fetchAll(PDO::FETCH_KEY_PAIR) ?: [];

            // Alertes mÃ©dicales
            $stmt = $pdo->query("
                SELECT COUNT(DISTINCT c.id) AS total 
                FROM candidat c
                INNER JOIN candidat_medical m ON m.candidat_id = c.id
                WHERE (c.supprimer = 0 OR c.supprimer IS NULL)
                  AND (m.has_allergies = 1 OR m.has_maladie_chronique = 1 OR m.has_maladie_cardiaque = 1 OR m.has_operation = 1)
            ");
            $stats['medical_alerts'] = (int)($stmt->fetchColumn() ?: 0);

            // Total utilisateurs
            $stmt = $pdo->query("SELECT COUNT(*) AS total FROM utilisateur WHERE actif = 1");
            $stats['total_utilisateurs'] = (int)($stmt->fetchColumn() ?: 0);

        } catch (PDOException $e) {
            error_log("Erreur calcul stats dashboard: " . $e->getMessage());
        }

        return $stats;
    }
}