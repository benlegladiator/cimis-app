<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

require_once __DIR__ . '/../../Services/DashboardService.php';

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        global $pdo;
        if (!$pdo) {
            require_once base_path('config/config.php');
        }

        $stats = \getDashboardStats($pdo);
        return view('dashboard.index', compact('stats'));
    }

    public function siadoc(Request $request)
    {
        global $pdo;
        if (!$pdo) {
            require_once base_path('config/config.php');
        }

        return view('siadoc.dashboard');
    }
}
