<?php
namespace App\Http\Controllers\Api;

require_once __DIR__ . '/../../Services/SiadocApiService.php';

class SiadocApiController {
    public function handle($pdo) {
        \handleSiadocApiRequest($pdo);
    }
}